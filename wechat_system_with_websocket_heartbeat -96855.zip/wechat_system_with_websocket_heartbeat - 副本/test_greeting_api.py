import requests
import json
import time
from datetime import datetime

def test_greeting_api():
    """测试问候API的各种情况"""
    base_url = "http://127.0.0.1:5000"
    
    print("\n测试1: 用户不存在")
    response = requests.post(
        f"{base_url}/api/greeting",
        json={"user_id": "nonexistent_user"}
    )
    print(f"状态码: {response.status_code}")
    print(f"响应: {json.dumps(response.json(), ensure_ascii=False, indent=2)}")
    
    print("\n测试2: 用户存在但在安静时间内")
    current_time = datetime.now().strftime("%H:%M")
    response = requests.post(
        f"{base_url}/api/greeting",
        json={"user_id": "testuser"}
    )
    print(f"当前时间: {current_time}")
    print(f"状态码: {response.status_code}")
    print(f"响应: {json.dumps(response.json(), ensure_ascii=False, indent=2)}")
    
    print("\n测试3: 模拟用户有最近聊天记录")
    chat_response = requests.post(
        f"{base_url}/api/chat",
        json={"user_id": "testuser", "content": "测试消息", "nameuser": "测试用户"}
    )
    print(f"聊天消息状态码: {chat_response.status_code}")
    
    response = requests.post(
        f"{base_url}/api/greeting",
        json={"user_id": "testuser"}
    )
    print(f"状态码: {response.status_code}")
    print(f"响应: {json.dumps(response.json(), ensure_ascii=False, indent=2)}")
    
    print("\n测试完成")

if __name__ == "__main__":
    test_greeting_api()
