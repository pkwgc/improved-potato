import json
import logging
from response_validator import ResponseValidator
from intent_classifier import IntentClassifier
from test_ai_service import TestAIService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_response_validator():
    """测试响应验证器"""
    print("\n===== 测试响应验证器 =====")
    validator = ResponseValidator()

    valid_response = {
        'reply': '您好，有什么可以帮您的？',
        'intent_type': 'no_intent',
        'intent_details': {
            'name': None,
            'confidence': 0.0,
            'entities': {}
        },
        'user_info_detected': {},
        'order_info': None
    }

    print('测试有效响应:')
    print(f'验证结果: {validator.validate_response(valid_response)}')

    invalid_response1 = {
        'reply': '您好，有什么可以帮您的？'
    }

    print('\n测试无效响应 (缺少必要字段):')
    print(f'验证结果: {validator.validate_response(invalid_response1)}')
    print('修正后:')
    fixed1 = validator.fix_response(invalid_response1)
    print(json.dumps(fixed1, ensure_ascii=False, indent=2))

    invalid_response2 = {
        'reply': '您好，有什么可以帮您的？',
        'intent_type': 'unknown',
        'intent_details': {
            'name': 'test',
            'confidence': 0.5,
            'entities': {}
        }
    }

    print('\n测试无效响应 (错误的intent_type值):')
    print(f'验证结果: {validator.validate_response(invalid_response2)}')
    print('修正后:')
    fixed2 = validator.fix_response(invalid_response2)
    print(json.dumps(fixed2, ensure_ascii=False, indent=2))

    string_response = '您好，有什么可以帮您的？'
    print('\n测试字符串响应:')
    print('修正后:')
    fixed3 = validator.fix_response(string_response)
    print(json.dumps(fixed3, ensure_ascii=False, indent=2))

def test_intent_classifier():
    """测试意图分类器"""
    print("\n===== 测试意图分类器 =====")
    classifier = IntentClassifier()

    order_message = '我想买两盒龙井茶，多少钱？'
    order_result = classifier.classify_intent(order_message)
    print('\n测试下单意图消息:')
    print(json.dumps(order_result, ensure_ascii=False, indent=2))

    inventory_message = '你们还有西湖龙井茶吗？'
    inventory_result = classifier.classify_intent(inventory_message)
    print('\n测试查询库存意图消息:')
    print(json.dumps(inventory_result, ensure_ascii=False, indent=2))

    price_message = '这个茶叶多少钱一斤？'
    price_result = classifier.classify_intent(price_message)
    print('\n测试查询价格意图消息:')
    print(json.dumps(price_result, ensure_ascii=False, indent=2))

    chat_message = '今天天气真不错啊'
    chat_result = classifier.classify_intent(chat_message)
    print('\n测试闲聊消息:')
    print(json.dumps(chat_result, ensure_ascii=False, indent=2))

    no_intent_message = '你好'
    no_intent_result = classifier.classify_intent(no_intent_message)
    print('\n测试无意图消息:')
    print(json.dumps(no_intent_result, ensure_ascii=False, indent=2))

def test_ai_service_extract():
    """测试AI服务的提取方法"""
    print("\n===== 测试AI服务的提取方法 =====")
    
    ai_service = TestAIService(api_key="test_key", base_url="test_url")
    
    json_block_response = """
    这是AI的回复。

    ```json
    {
        "reply": "您好，我可以帮您查询库存。",
        "intent_type": "specific_intent",
        "intent_details": {
            "name": "查询库存",
            "confidence": 0.85,
            "entities": {
                "product": "龙井茶",
                "quantity": 2,
                "unit": "盒"
            }
        },
        "user_info_detected": {
            "preferences": "喜欢龙井茶"
        }
    }
    ```
    """
    
    print('\n测试JSON代码块格式响应:')
    reply, confidence, intent_data = ai_service.extract_reply_and_confidence(json_block_response)
    print(f'提取的回复: {reply}')
    print(f'提取的置信度: {confidence}')
    print(f'提取的意图数据: {json.dumps(intent_data, ensure_ascii=False, indent=2)}')
    
    json_response = '{"reply":"您好，我可以帮您下单。","intent_type":"specific_intent","intent_details":{"name":"下单","confidence":0.92,"entities":{"product":"西湖龙井","quantity":1,"unit":"斤"}},"user_info_detected":{"address":"杭州市西湖区"},"order_info":{"order_id":"ORD12345","status":"pending","products":["西湖龙井 1斤"],"total_amount":280.0}}'
    
    print('\n测试普通JSON格式响应:')
    reply, confidence, intent_data = ai_service.extract_reply_and_confidence(json_response)
    print(f'提取的回复: {reply}')
    print(f'提取的置信度: {confidence}')
    print(f'提取的意图数据: {json.dumps(intent_data, ensure_ascii=False, indent=2)}')
    
    text_response = "您好，很高兴为您服务。今天天气不错，有什么可以帮您的吗？"
    
    print('\n测试纯文本响应:')
    reply, confidence, intent_data = ai_service.extract_reply_and_confidence(text_response)
    print(f'提取的回复: {reply}')
    print(f'提取的置信度: {confidence}')
    print(f'提取的意图数据: {json.dumps(intent_data, ensure_ascii=False, indent=2)}')

if __name__ == "__main__":
    print("开始测试AI响应格式处理...")
    test_response_validator()
    test_intent_classifier()
    test_ai_service_extract()
    print("\n测试完成！")
