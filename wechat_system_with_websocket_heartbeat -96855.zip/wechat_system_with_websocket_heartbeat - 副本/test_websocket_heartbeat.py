#!/usr/bin/env python3
import socketio
import time
import sys

def test_websocket_heartbeat():
    """Test WebSocket connection and heartbeat functionality"""
    sio = socketio.Client()
    
    @sio.event
    def connect():
        print('✅ WebSocket连接成功')
        sio.emit('authenticate', {'user_id': 'test_user'})
    
    @sio.event
    def authenticated(data):
        print('✅ WebSocket认证成功:', data)
        sio.emit('join_wechat_room', {'user_id': 'test_user', 'wechat_id': 'test_user'})
    
    @sio.event
    def heartbeat_ack(data):
        print('✅ 心跳确认:', data)
    
    @sio.event
    def disconnect():
        print('❌ WebSocket断开连接')
    
    try:
        sio.connect('http://localhost:5000')
        time.sleep(2)
        sio.emit('heartbeat', {'user_id': 'test_user'})
        time.sleep(2)
        sio.disconnect()
        print('✅ WebSocket测试完成')
        return True
    except Exception as e:
        print(f'❌ WebSocket测试失败: {e}')
        return False

if __name__ == '__main__':
    success = test_websocket_heartbeat()
    sys.exit(0 if success else 1)
