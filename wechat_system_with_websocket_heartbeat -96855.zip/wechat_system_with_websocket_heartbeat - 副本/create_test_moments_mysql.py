import os
import logging
from datetime import datetime, timedelta
from database import get_db, User, WechatContact, Moment, MomentComment, create_tables

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_test_moments_mysql():
    """为MySQL数据库创建测试朋友圈数据"""
    try:
        
        create_tables()
        logger.info("数据库表创建完成")
        
        db = next(get_db())
        
        user = db.query(User).filter(User.user_id == "test_user").first()
        if not user:
            user = User(
                user_id="test_user",
                username="测试用户",
                password="test123",
                is_admin=False,
                token_balance=1000
            )
            db.add(user)
            db.commit()
            logger.info("创建测试用户: test_user")
        else:
            logger.info("使用现有用户: test_user")
        
        wechat_contact = db.query(WechatContact).filter(
            WechatContact.wechat_id == "wxid_test123",
            WechatContact.owner_id == user.id
        ).first()
        if not wechat_contact:
            wechat_contact = WechatContact(
                wechat_id="wxid_test123",
                nickname="测试微信号",
                owner_id=user.id,
                parent_id=None,
                is_group=False
            )
            db.add(wechat_contact)
            db.commit()
            logger.info("创建测试微信账号: wxid_test123")
        else:
            logger.info("使用现有微信账号: wxid_test123")
        
        existing_moments = db.query(Moment).filter(Moment.owner_id == user.id).count()
        if existing_moments == 0:
            test_moments = [
                {
                    "wechat_id": "wxid_test123",
                    "content": "今天天气真不错，出去走走！☀️",
                    "media_urls": ["https://picsum.photos/400/300?random=1", "https://picsum.photos/400/300?random=2"],
                    "like_count": 15,
                    "comment_count": 3,
                    "created_time": datetime.now() - timedelta(hours=2)
                },
                {
                    "wechat_id": "wxid_test123", 
                    "content": "分享一下今天的美食 🍜",
                    "media_urls": ["https://picsum.photos/400/300?random=3"],
                    "like_count": 8,
                    "comment_count": 1,
                    "created_time": datetime.now() - timedelta(hours=5)
                },
                {
                    "wechat_id": "wxid_test123",
                    "content": "工作中的小确幸 💪 #努力奋斗",
                    "media_urls": [],
                    "like_count": 12,
                    "comment_count": 2,
                    "created_time": datetime.now() - timedelta(days=1)
                },
                {
                    "wechat_id": "wxid_test123",
                    "content": "周末愉快！和朋友们聚餐 🎉",
                    "media_urls": ["https://picsum.photos/400/300?random=4", "https://picsum.photos/400/300?random=5", "https://picsum.photos/400/300?random=6"],
                    "like_count": 25,
                    "comment_count": 5,
                    "created_time": datetime.now() - timedelta(days=2)
                },
                {
                    "wechat_id": "wxid_test123",
                    "content": "读书笔记：今天学到了很多新知识 📚",
                    "media_urls": ["https://picsum.photos/400/300?random=7"],
                    "like_count": 6,
                    "comment_count": 1,
                    "created_time": datetime.now() - timedelta(days=3)
                }
            ]
            
            for i, moment_data in enumerate(test_moments):
                moment = Moment(
                    wechat_id=moment_data["wechat_id"],
                    content=moment_data["content"],
                    media_urls=moment_data["media_urls"],
                    like_count=moment_data["like_count"],
                    comment_count=moment_data["comment_count"],
                    owner_id=user.id,
                    created_time=moment_data["created_time"]
                )
                db.add(moment)
                db.commit()
                
                if moment_data["comment_count"] > 0:
                    for j in range(moment_data["comment_count"]):
                        comment_content = [
                            "太棒了！👍",
                            "赞同你的观点",
                            "哈哈哈，有趣",
                            "我也想去",
                            "拍得真好看",
                            "学习了",
                            "支持支持！"
                        ]
                        
                        comment = MomentComment(
                            moment_id=moment.id,
                            parent_id=None,
                            wechat_id=f"friend_{j+1}",
                            content=comment_content[j % len(comment_content)],
                            created_time=moment_data["created_time"] + timedelta(minutes=(j+1)*10)
                        )
                        db.add(comment)
                        
                        if j == 0 and i == 0:
                            reply = MomentComment(
                                moment_id=moment.id,
                                parent_id=comment.id,
                                wechat_id="wxid_test123",
                                content="谢谢支持！😊",
                                created_time=moment_data["created_time"] + timedelta(minutes=15)
                            )
                            db.add(reply)
                
                logger.info(f"创建测试朋友圈 {i+1}: {moment.content[:20]}...")
            
            db.commit()
            logger.info("✅ MySQL测试朋友圈数据创建完成！")
            logger.info(f"共创建了 {len(test_moments)} 条朋友圈和相关评论")
        else:
            logger.info(f"MySQL数据库中已存在 {existing_moments} 条朋友圈数据")
        
        db.close()
        
    except Exception as e:
        logger.error(f"❌ 创建MySQL测试数据失败: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    print("=== MySQL朋友圈测试数据创建工具 ===")
    print("确保您的MySQL数据库连接配置正确...")
    create_test_moments_mysql()
