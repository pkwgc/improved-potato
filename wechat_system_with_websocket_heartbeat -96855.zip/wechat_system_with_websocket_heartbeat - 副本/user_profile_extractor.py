import re
import json
import logging
from sqlalchemy.orm import Session
from database import User

logger = logging.getLogger(__name__)

IDENTITY_PATTERNS = [
    r"我是(?:一[名个])?([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)",  # 我是一名医生
    r"(?:我|俺|咱)(?:的)?职业(?:是|为)?([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)",  # 我的职业是医生
    r"(?:我|俺|咱)(?:是|在)([^，。！？,.!?]+)(?:工作|上班)(?:，|。|！|？|,|.|!|\?|$)",  # 我在医院工作
    r"作为(?:一[名个])?([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)"  # 作为一名教师
]

HOBBY_PATTERNS = [
    r"(?:我|俺|咱)(?:喜欢|热爱|爱好是|爱好有)([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)",  # 我喜欢旅游
    r"(?:我|俺|咱)(?:平时|经常|有空|闲暇时|业余时间)?(?:会|喜欢)?([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)",  # 我平时会打篮球
    r"(?:我|俺|咱)(?:的)?爱好(?:是|有)?([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)",  # 我的爱好是摄影
    r"(?:我|俺|咱)(?:最近|一直|常常)(?:在)?([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)"  # 我最近在学习钢琴
]

ORDER_INFO_PATTERNS = {
    "address": [
        r"地址[:：]?\s*([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)",  # 地址：北京市海淀区
        r"送[至到][:：]?\s*([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)",  # 送至：上海市浦东新区
        r"(?:收货|邮寄|配送)地址[:：]?\s*([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)"  # 收货地址：广州市天河区
    ],
    "name": [
        r"(?:收件人|联系人|收货人)[:：]?\s*([^，。！？,.!?0-9]{2,5})(?:，|。|！|？|,|.|!|\?|$)",  # 收件人：张三
        r"(?<=[省市区县])[^，。！？,.!?0-9]{2,5}(?=，|。|！|？|,|.|!|\?|$)"  # 地址后面紧跟的名字
    ],
    "phone": [
        r"(?:电话|手机|联系方式|联系电话)[:：]?\s*(1[3-9]\d{9})(?:，|。|！|？|,|.|!|\?|$)",  # 电话：13812345678
        r"(?<![0-9])(1[3-9]\d{9})(?![0-9])"  # 独立的手机号
    ]
}

OTHER_INFO_PATTERNS = {
    "age": [
        r"(?:我|俺|咱)(?:今年|现在)?(\d+)岁(?:，|。|！|？|,|.|!|\?|$)",  # 我今年30岁
        r"(?:我|俺|咱)(?:的)?年龄(?:是)?(\d+)(?:，|。|！|？|,|.|!|\?|$)"  # 我的年龄是30
    ],
    "gender": [
        r"(?:我|俺|咱)是(男生|女生|男孩|女孩|男人|女人|男性|女性)(?:，|。|！|？|,|.|!|\?|$)"  # 我是男生
    ],
    "education": [
        r"(?:我|俺|咱)(?:是|在读|毕业于)([^，。！？,.!?]+)(?:大学|学院|学校)(?:，|。|！|？|,|.|!|\?|$)",  # 我毕业于北京大学
        r"(?:我|俺|咱)(?:的)?学历(?:是)?([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)"  # 我的学历是本科
    ],
    "location": [
        r"(?:我|俺|咱)(?:住在|来自|在)([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)",  # 我住在北京
        r"(?:我|俺|咱)(?:的)?家(?:在|是)([^，。！？,.!?]+)(?:，|。|！|？|,|.|!|\?|$)"  # 我的家在上海
    ]
}

IDENTITY_KEYWORDS = ["我是", "职业", "工作", "上班", "作为"]
HOBBY_KEYWORDS = ["喜欢", "爱好", "兴趣", "热爱", "平时会", "经常", "闲暇时"]
ORDER_INFO_KEYWORDS = ["地址", "电话", "手机", "联系", "收货", "邮寄", "配送", "收件人"]
OTHER_INFO_KEYWORDS = {
    "age": ["岁", "年龄"],
    "gender": ["男生", "女生", "男孩", "女孩", "男人", "女人", "男性", "女性"],
    "education": ["大学", "学院", "学校", "学历", "毕业"],
    "location": ["住在", "来自", "家在"]
}

def extract_identity(text):
    """从文本中提取用户身份信息"""
    if not any(keyword in text for keyword in IDENTITY_KEYWORDS):
        return None
    
    for pattern in IDENTITY_PATTERNS:
        match = re.search(pattern, text)
        if match:
            identity = match.group(1).strip()
            if len(identity) > 1 and len(identity) < 20:  # 合理的身份长度
                return identity
    return None

def extract_hobbies(text):
    """从文本中提取用户爱好信息"""
    if not any(keyword in text for keyword in HOBBY_KEYWORDS):
        return None
    
    hobbies = []
    for pattern in HOBBY_PATTERNS:
        matches = re.finditer(pattern, text)
        for match in matches:
            hobby = match.group(1).strip()
            if len(hobby) > 1 and len(hobby) < 20:  # 合理的爱好长度
                hobbies.append(hobby)
    
    if hobbies:
        return "、".join(hobbies)
    return None

def extract_other_info(text):
    """从文本中提取其他重要信息"""
    other_info = {}
    
    for info_type, keywords in OTHER_INFO_KEYWORDS.items():
        if not any(keyword in text for keyword in keywords):
            continue
        
        for pattern in OTHER_INFO_PATTERNS.get(info_type, []):
            match = re.search(pattern, text)
            if match:
                value = match.group(1).strip()
                if value:
                    other_info[info_type] = value
                    break
    
    return other_info if other_info else None

def extract_order_info(text):
    """从文本中提取订单和联系信息"""
    order_info = {}
    
    if not any(keyword in text for keyword in ORDER_INFO_KEYWORDS):
        return None
    
    for pattern in ORDER_INFO_PATTERNS.get("address", []):
        match = re.search(pattern, text)
        if match:
            address = match.group(1).strip()
            if address and len(address) > 5:  # 地址通常较长
                order_info["address"] = address
                break
    
    if "address" not in order_info:
        address_pattern = r'([^，。！？,.!?]*?(?:省|市|区|县|路|街|号)[^，。！？,.!?]*?)(?:，|。|！|？|,|.|!|\?|$)'
        match = re.search(address_pattern, text)
        if match:
            address = match.group(1).strip()
            if address and len(address) > 5:
                order_info["address"] = address
    
    for pattern in ORDER_INFO_PATTERNS.get("name", []):
        try:
            match = re.search(pattern, text)
            if match and match.groups():
                name = match.group(1).strip()
                if name and 2 <= len(name) <= 5:  # 姓名通常2-5个字符
                    order_info["name"] = name
                    break
        except Exception as e:
            logger.error(f"提取姓名时出错: {str(e)}")
    
    if "name" not in order_info:
        chinese_name_pattern = r'(?<![^\s，,。；;])([\u4e00-\u9fa5]{2,3})(?![^\s，,。；;])'
        matches = re.finditer(chinese_name_pattern, text)
        for match in matches:
            potential_name = match.group(1)
            common_words = ["龙井", "铁观音", "普洱", "大红袍", "绿茶", "红茶", "乌龙"]
            if potential_name not in common_words:
                order_info["name"] = potential_name
                break
    
    for pattern in ORDER_INFO_PATTERNS.get("phone", []):
        match = re.search(pattern, text)
        if match:
            phone = match.group(1).strip()
            if phone and len(phone) == 11:  # 手机号通常11位
                order_info["phone"] = phone
                break
    
    if "phone" not in order_info:
        phone_pattern = r'(?<![0-9])(1[3-9]\d{9})(?![0-9])'
        match = re.search(phone_pattern, text)
        if match:
            phone = match.group(1).strip()
            if phone and len(phone) == 11:
                order_info["phone"] = phone
    
    return order_info if order_info else None

def extract_user_profile_info(text):
    """从文本中提取用户资料信息"""
    identity = extract_identity(text)
    hobbies = extract_hobbies(text)
    other_info = extract_other_info(text)
    order_info = extract_order_info(text)
    
    result = {}
    if identity:
        result["identity"] = identity
    if hobbies:
        result["hobbies"] = hobbies
    if other_info:
        result["other_info"] = other_info
    if order_info:
        result["order_info"] = order_info
    
    return result

def update_user_profile_from_message(db: Session, user_id: str, message: str, ai_response_json=None):
    """从用户消息中提取信息并更新用户资料
    
    参数:
        db: 数据库会话
        user_id: 用户ID
        message: 用户消息文本
        ai_response_json: AI返回的JSON数据（可选）
    """
    try:
        user = db.query(User).filter(User.user_id == user_id).first()
        if not user:
            logger.warning(f"用户不存在: {user_id}")
            return False
        
        try:
            current_profile_data = json.loads(user.profile_data) if user.profile_data else {}
        except:
            current_profile_data = {}
        
        if "contact_info" not in current_profile_data:
            current_profile_data["contact_info"] = {}
        
        if "preferences" not in current_profile_data:
            current_profile_data["preferences"] = {}
        
        if ai_response_json:
            logger.info(f"从AI返回的JSON中提取用户信息: {user_id}")
            
            if ai_response_json.get("trigger_api") == True and "slots" in ai_response_json:
                slots = ai_response_json.get("slots", {})
                logger.info(f"处理AI响应中的slots数据: {slots}")
                
                if "address" in slots:
                    current_profile_data["contact_info"]["address"] = slots["address"]
                    logger.info(f"从意图slots中更新用户地址: {user_id} -> {slots['address']}")
                
                if "name" in slots:
                    current_profile_data["contact_info"]["name"] = slots["name"]
                    logger.info(f"从意图slots中更新用户姓名: {user_id} -> {slots['name']}")
                
                if "phone" in slots:
                    current_profile_data["contact_info"]["phone"] = slots["phone"]
                    logger.info(f"从意图slots中更新用户电话: {user_id} -> {slots['phone']}")
                
                for key, value in slots.items():
                    if key not in ["address", "name", "phone"]:  # 已处理的字段跳过
                        current_profile_data["preferences"][key] = value
                        logger.info(f"从意图slots中更新用户偏好 {key}: {user_id} -> {value}")
            
            if "user_info" in ai_response_json:
                user_info = ai_response_json.get("user_info", {})
                
                if "name" in user_info:
                    current_profile_data["contact_info"]["name"] = user_info["name"]
                    logger.info(f"从user_info中更新用户姓名: {user_id} -> {user_info['name']}")
                
                if "phone" in user_info:
                    current_profile_data["contact_info"]["phone"] = user_info["phone"]
                    logger.info(f"从user_info中更新用户电话: {user_id} -> {user_info['phone']}")
                
                if "address" in user_info:
                    current_profile_data["contact_info"]["address"] = user_info["address"]
                    logger.info(f"从user_info中更新用户地址: {user_id} -> {user_info['address']}")
            
            if "user_preferences" in ai_response_json:
                preferences = ai_response_json.get("user_preferences", {})
                
                for key, value in preferences.items():
                    current_profile_data["preferences"][key] = value
                    logger.info(f"从user_preferences中更新用户偏好 {key}: {user_id} -> {value}")
                
                if "tea_types" in preferences and isinstance(preferences["tea_types"], list):
                    tea_types = "、".join(preferences["tea_types"])
                    if not user.hobbies:
                        user.hobbies = f"喜欢{tea_types}茶"
                    elif "茶" not in user.hobbies:
                        user.hobbies = f"{user.hobbies}、喜欢{tea_types}茶"
                    logger.info(f"从偏好中更新用户爱好: {user_id} -> {user.hobbies}")
        
        profile_info = extract_user_profile_info(message)
        if profile_info:
            if "identity" in profile_info and (not user.identity or len(profile_info["identity"]) > len(user.identity)):
                user.identity = profile_info["identity"]
                logger.info(f"从消息中更新用户身份: {user_id} -> {profile_info['identity']}")
            
            if "hobbies" in profile_info:
                if not user.hobbies:
                    user.hobbies = profile_info["hobbies"]
                    logger.info(f"从消息中更新用户爱好: {user_id} -> {profile_info['hobbies']}")
                else:
                    current_hobbies = set(user.hobbies.split("、"))
                    new_hobbies = set(profile_info["hobbies"].split("、"))
                    merged_hobbies = current_hobbies.union(new_hobbies)
                    user.hobbies = "、".join(merged_hobbies)
                    logger.info(f"从消息中合并用户爱好: {user_id} -> {user.hobbies}")
            
            if "other_info" in profile_info:
                current_profile_data.update(profile_info["other_info"])
                logger.info(f"从消息中更新用户其他信息: {user_id} -> {profile_info['other_info']}")
            
            if "order_info" in profile_info:
                if "address" in profile_info["order_info"]:
                    current_profile_data["contact_info"]["address"] = profile_info["order_info"]["address"]
                    logger.info(f"从消息中更新用户地址: {user_id} -> {profile_info['order_info']['address']}")
                
                if "name" in profile_info["order_info"]:
                    current_profile_data["contact_info"]["name"] = profile_info["order_info"]["name"]
                    logger.info(f"从消息中更新用户姓名: {user_id} -> {profile_info['order_info']['name']}")
                
                if "phone" in profile_info["order_info"]:
                    current_profile_data["contact_info"]["phone"] = profile_info["order_info"]["phone"]
                    logger.info(f"从消息中更新用户电话: {user_id} -> {profile_info['order_info']['phone']}")
        
        user.profile_data = json.dumps(current_profile_data, ensure_ascii=False)
        db.commit()
        return True
    except Exception as e:
        logger.error(f"更新用户资料时出错: {str(e)}")
        return False

def analyze_message_intent(message):
    """分析消息意图，判断是否是用户在主动分享个人信息"""
    intro_keywords = ["自我介绍", "我叫", "我是", "我的情况", "关于我", "我的基本情况"]
    if any(keyword in message for keyword in intro_keywords):
        return True
    
    has_identity = any(keyword in message for keyword in IDENTITY_KEYWORDS)
    has_hobby = any(keyword in message for keyword in HOBBY_KEYWORDS)
    if has_identity and has_hobby:
        return True
    
    has_order_info = any(keyword in message for keyword in ORDER_INFO_KEYWORDS)
    if has_order_info:
        has_address = any(re.search(pattern, message) for pattern in ORDER_INFO_PATTERNS.get("address", []))
        has_phone = any(re.search(pattern, message) for pattern in ORDER_INFO_PATTERNS.get("phone", []))
        if has_address or has_phone:
            return True
    
    if len(message) > 50 and (has_identity or has_hobby):
        return True
    
    return False
