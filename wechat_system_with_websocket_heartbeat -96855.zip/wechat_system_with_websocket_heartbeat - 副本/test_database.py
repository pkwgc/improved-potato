from database import get_db, User, WechatContact, IntentTracking

def test_database_models():
    """Test that database models are working correctly"""
    try:
        db = next(get_db())
        print('Testing database models...')
        
        users_count = db.query(User).count()
        contacts_count = db.query(WechatContact).count()
        
        print(f'Users count: {users_count}')
        print(f'Contacts count: {contacts_count}')
        print('Database models working correctly!')
        
        db.close()
        return True
    except Exception as e:
        print(f'Database test failed: {str(e)}')
        return False

if __name__ == "__main__":
    test_database_models()
