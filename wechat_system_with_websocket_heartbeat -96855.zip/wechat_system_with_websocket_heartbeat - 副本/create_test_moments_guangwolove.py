import os
import json
import logging
from datetime import datetime, timedelta
from database import get_db, User, WechatContact, Moment, MomentComment, create_tables

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_test_moments_guangwolove():
    """为用户 guangwolove 创建测试朋友圈数据（MySQL兼容版）"""
    try:
        logger.info("开始连接MySQL数据库...")
        
        create_tables()
        logger.info("✅ 数据库表创建完成")
        
        db = next(get_db())
        
        user = db.query(User).filter(User.user_id == "guangwolove").first()
        if not user:
            logger.error("❌ 用户 guangwolove 不存在！")
            logger.error("请先确保用户 guangwolove 已经在系统中注册")
            return
        else:
            logger.info("✅ 找到用户: guangwolove")
        
        wechat_contact = db.query(WechatContact).filter(
            WechatContact.wechat_id == "wxid_1d23456",
            WechatContact.owner_id == user.id
        ).first()
        if not wechat_contact:
            wechat_contact = WechatContact(
                wechat_id="wxid_1d23456",
                nickname="我的微信号",
                owner_id=user.id,
                parent_id=None,
                is_group=False
            )
            db.add(wechat_contact)
            db.commit()
            logger.info("✅ 创建微信账号: wxid_1d23456")
        else:
            logger.info("✅ 使用现有微信账号: wxid_1d23456")
        
        try:
            existing_moments = db.query(Moment).filter(Moment.owner_id == user.id).count()
            if existing_moments > 0:
                logger.info(f"✅ 账号中已存在 {existing_moments} 条朋友圈数据")
                logger.info("如需重新创建，请先删除现有数据")
                return
        except Exception as e:
            logger.info("朋友圈表不存在或为空，开始创建测试数据...")
        
        test_moments = [
            {
                "wechat_id": "wxid_1d23456",
                "content": "今天天气真不错！☀️ 和朋友们一起去公园散步，心情特别好 😊",
                "media_urls": ["https://picsum.photos/400/300?random=1", "https://picsum.photos/400/300?random=2"],
                "like_count": 15,
                "comment_count": 3,
                "created_time": datetime.now() - timedelta(hours=2)
            },
            {
                "wechat_id": "wxid_1d23456", 
                "content": "刚刚完成了一个重要的项目 💪 感谢团队的努力！",
                "media_urls": ["https://picsum.photos/400/300?random=3"],
                "like_count": 28,
                "comment_count": 8,
                "created_time": datetime.now() - timedelta(hours=5)
            },
            {
                "wechat_id": "wxid_1d23456",
                "content": "周末的美食时光 🍕🍰 生活就是要享受这些小确幸",
                "media_urls": ["https://picsum.photos/400/300?random=4", "https://picsum.photos/400/300?random=5", "https://picsum.photos/400/300?random=6"],
                "like_count": 42,
                "comment_count": 12,
                "created_time": datetime.now() - timedelta(days=1)
            },
            {
                "wechat_id": "wxid_1d23456",
                "content": "读书笔记：《人生的智慧》📚 每一页都有新的感悟",
                "media_urls": ["https://picsum.photos/400/300?random=7"],
                "like_count": 19,
                "comment_count": 5,
                "created_time": datetime.now() - timedelta(days=2)
            },
            {
                "wechat_id": "wxid_1d23456",
                "content": "夜晚的城市灯火 🌃 每次看到都觉得很震撼",
                "media_urls": ["https://picsum.photos/400/300?random=8", "https://picsum.photos/400/300?random=9"],
                "like_count": 33,
                "comment_count": 7,
                "created_time": datetime.now() - timedelta(days=3)
            }
        ]
        
        for i, moment_data in enumerate(test_moments):
            media_urls_json = json.dumps(moment_data["media_urls"], ensure_ascii=False)
            
            moment = Moment(
                wechat_id=moment_data["wechat_id"],
                content=moment_data["content"],
                media_urls=media_urls_json,  # 存储为JSON字符串
                like_count=moment_data["like_count"],
                comment_count=moment_data["comment_count"],
                owner_id=user.id,
                created_time=moment_data["created_time"]
            )
            db.add(moment)
            db.commit()
            
            if moment_data["comment_count"] > 0:
                comment_templates = [
                    "太棒了！👍",
                    "赞同你的观点",
                    "哈哈哈，有趣 😄",
                    "我也想去",
                    "拍得真好看 📸",
                    "学习了 📚",
                    "支持支持！💪",
                    "羡慕啊",
                    "下次一起",
                    "真不错呢",
                    "厉害厉害",
                    "好棒啊！"
                ]
                
                for j in range(min(moment_data["comment_count"], len(comment_templates))):
                    comment = MomentComment(
                        moment_id=moment.id,
                        parent_id=None,
                        wechat_id=f"friend_{j+1}",
                        content=comment_templates[j],
                        created_time=moment_data["created_time"] + timedelta(minutes=(j+1)*10)
                    )
                    db.add(comment)
                    
                    if j == 0 and i == 0:
                        reply = MomentComment(
                            moment_id=moment.id,
                            parent_id=comment.id,
                            wechat_id="wxid_1d23456",
                            content="谢谢大家的支持！😊",
                            created_time=moment_data["created_time"] + timedelta(minutes=15)
                        )
                        db.add(reply)
            
            logger.info(f"✅ 创建朋友圈 {i+1}: {moment.content[:30]}...")
        
        db.commit()
        logger.info("🎉 朋友圈测试数据创建完成！")
        logger.info(f"📊 为用户 guangwolove 创建了 {len(test_moments)} 条朋友圈")
        logger.info(f"📱 微信号: wxid_1d23456")
        logger.info("🚀 现在可以登录系统查看朋友圈了！")
        logger.info("💡 登录后点击侧边栏的'朋友圈管理'菜单")
        
        db.close()
        
    except Exception as e:
        logger.error(f"❌ 创建朋友圈数据失败: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    print("=== guangwolove 朋友圈测试数据创建工具 ===")
    print("✅ 专为用户 guangwolove 定制")
    print("✅ 微信号: wxid_1d23456")
    print("✅ MySQL兼容版本")
    print("确保您的MySQL数据库连接配置正确...")
    create_test_moments_guangwolove()
