import json
import logging
import re
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from database import Base, User
from user_profile_extractor import update_user_profile_from_message

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def setup_test_db():
    """创建内存数据库用于测试"""
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    return Session()

def extract_json_from_raw_content(raw_content):
    """从原始回复内容中提取JSON"""
    try:
        match = re.search(r'{.*}', raw_content, re.DOTALL)
        if match:
            json_str = re.sub(r'(?<!\\)\\(?![\\/"bfnrtu])', r'\\\\', match.group())
            return json.loads(json_str)
    except Exception as e:
        logger.error(f"从原始回复内容提取JSON失败: {str(e)}")
    return None

def test_raw_content_extraction():
    """测试从原始回复内容中提取用户信息"""
    db = setup_test_db()
    
    test_user = User(user_id="pk_wgc", username="pk_wgc")
    db.add(test_user)
    db.commit()
    
    user_message = "帮我来2斤龙井，地址：海南省海口市龙华区城西商务中心1101，李庭皇，15203699059"
    
    raw_content = '''{
  "reply": "龙井这就备好\\地址记下啦\\明天让你闻见茶香",
  "trigger_api": true,
  "intent": "购买",
  "industry": "茶叶",
  "api": "order_processing",
  "slots": {
    "tea_type": "西湖龙井",
    "amount": "2斤",
    "address": "海南省海口市龙华区城西商务中心1101",
    "name": "李庭皇",
    "phone": "15203699059"
  },
  "confidence": 1.0
}'''
    
    logger.info("开始测试从原始回复内容中提取用户信息")
    extracted_json = extract_json_from_raw_content(raw_content)
    
    if extracted_json:
        logger.info(f"从原始回复内容中提取到JSON: {json.dumps(extracted_json, ensure_ascii=False, indent=2)}")
        
        update_result = update_user_profile_from_message(db, "pk_wgc", user_message, extracted_json)
        
        updated_user = db.query(User).filter(User.user_id == "pk_wgc").first()
        logger.info(f"更新结果: {update_result}")
        logger.info(f"用户身份: {updated_user.identity}")
        logger.info(f"用户爱好: {updated_user.hobbies}")
        logger.info(f"用户资料: {updated_user.profile_data}")
        
        if updated_user.profile_data:
            profile_data = json.loads(updated_user.profile_data)
            logger.info(f"联系信息: {json.dumps(profile_data.get('contact_info', {}), ensure_ascii=False, indent=2)}")
            logger.info(f"偏好信息: {json.dumps(profile_data.get('preferences', {}), ensure_ascii=False, indent=2)}")
    else:
        logger.error("从原始回复内容中提取JSON失败")

def test_user_info_raw_content():
    """测试从包含user_info的原始回复内容中提取用户信息"""
    db = setup_test_db()
    
    test_user = User(user_id="test_user", username="测试用户")
    db.add(test_user)
    db.commit()
    
    user_message = "我叫阿杰，喜欢花香型的茶，特别是龙井和小种，平时自己喝，不需要礼品包装。我住在广州市天河区珠江新城123号，电话是13988889999"
    
    raw_content = '''{
  "reply": "已记录您的信息，感谢分享",
  "trigger_api": false,
  "user_info": {
    "name": "阿杰",
    "phone": "13988889999",
    "address": "广州市天河区珠江新城123号"
  },
  "user_preferences": {
    "flavor": "花香型",
    "tea_types": ["龙井", "小种"],
    "usage_scenario": ["自饮"],
    "gift_packaging": false,
    "chat_style": "幽默有趣"
  }
}'''
    
    logger.info("\n开始测试从包含user_info的原始回复内容中提取用户信息")
    extracted_json = extract_json_from_raw_content(raw_content)
    
    if extracted_json:
        logger.info(f"从原始回复内容中提取到JSON: {json.dumps(extracted_json, ensure_ascii=False, indent=2)}")
        
        update_result = update_user_profile_from_message(db, "test_user", user_message, extracted_json)
        
        updated_user = db.query(User).filter(User.user_id == "test_user").first()
        logger.info(f"更新结果: {update_result}")
        logger.info(f"用户身份: {updated_user.identity}")
        logger.info(f"用户爱好: {updated_user.hobbies}")
        logger.info(f"用户资料: {updated_user.profile_data}")
        
        if updated_user.profile_data:
            profile_data = json.loads(updated_user.profile_data)
            logger.info(f"联系信息: {json.dumps(profile_data.get('contact_info', {}), ensure_ascii=False, indent=2)}")
            logger.info(f"偏好信息: {json.dumps(profile_data.get('preferences', {}), ensure_ascii=False, indent=2)}")
    else:
        logger.error("从原始回复内容中提取JSON失败")

if __name__ == "__main__":
    test_raw_content_extraction()
    test_user_info_raw_content()
