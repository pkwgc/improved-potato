import os
import bcrypt
from database import get_db, User, Base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

def create_test_user():
    os.environ['USE_SQLITE'] = 'true'
    
    DATABASE_URL = "sqlite:///./test.db"
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False}
    )
    
    Base.metadata.create_all(engine)
    
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db = SessionLocal()
    
    try:
        existing_user = db.query(User).filter(User.user_id == 'testuser').first()
        if existing_user:
            password = "password123"
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            existing_user.password = hashed_password
            db.commit()
            print("Test user password updated successfully")
            return
        
        password = "password123"
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        
        user = User(
            user_id='testuser',
            username='测试用户',
            password=hashed_password,
            token_balance=1000,
            is_admin=False
        )
        db.add(user)
        db.commit()
        print("Test user created successfully")
    except Exception as e:
        print(f"Error creating test user: {str(e)}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    create_test_user()
