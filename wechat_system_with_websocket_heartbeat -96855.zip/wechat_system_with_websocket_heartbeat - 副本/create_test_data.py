import os
import sys
from datetime import datetime, timedelta
import random
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database import Base, User, WechatContact, WechatMessage, AIStrategy

os.environ['USE_SQLITE'] = 'true'

db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'wechat_system.db')
DATABASE_URL = f"sqlite:///{db_path}"
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}
)
print(f"使用SQLite数据库: {db_path}")

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
db = SessionLocal()

def create_tables():
    """创建所有表"""
    Base.metadata.create_all(bind=engine)

def create_test_user():
    """创建测试用户"""
    admin = db.query(User).filter(User.user_id == 'admin').first()
    if not admin:
        admin = User(user_id='admin', username='管理员', is_admin=True)
        db.add(admin)
        db.commit()
        print("已创建管理员用户")
    
    test_user = db.query(User).filter(User.user_id == 'test').first()
    if not test_user:
        test_user = User(user_id='test', username='测试用户', password='test')
        db.add(test_user)
        db.commit()
        print("已创建测试用户")
    
    return test_user

def create_ai_strategies():
    """创建AI策略"""
    strategies = [
        {
            "name": "默认策略",
            "description": "通用回复策略",
            "prompt_template": "你是一个友好的助手，请回答用户的问题。\n\n用户: {{message}}",
            "system_message": "你是一个友好的助手，请用简洁的语言回答问题。",
            "temperature": 0.7,
            "max_tokens": 2000
        },
        {
            "name": "客服策略",
            "description": "客服回复策略",
            "prompt_template": "你是一个专业的客服代表，请回答用户的问题。\n\n用户: {{message}}",
            "system_message": "你是一个专业的客服代表，请用礼貌的语言回答问题。",
            "temperature": 0.5,
            "max_tokens": 1500
        },
        {
            "name": "销售策略",
            "description": "销售回复策略",
            "prompt_template": "你是一个专业的销售代表，请回答用户的问题。\n\n用户: {{message}}",
            "system_message": "你是一个专业的销售代表，请用热情的语言回答问题。",
            "temperature": 0.8,
            "max_tokens": 2500
        }
    ]
    
    created_strategies = []
    for strategy_data in strategies:
        strategy = db.query(AIStrategy).filter(AIStrategy.name == strategy_data["name"]).first()
        if not strategy:
            strategy = AIStrategy(**strategy_data)
            db.add(strategy)
            created_strategies.append(strategy)
    
    if created_strategies:
        db.commit()
        print(f"已创建 {len(created_strategies)} 个AI策略")
    
    return db.query(AIStrategy).all()

def create_wechat_accounts(user):
    """创建微信账号"""
    accounts = [
        {
            "wechat_id": "wxid_123456",
            "nickname": "主要账号",
            "remark": "工作用微信",
            "is_group": False,
            "avatar": None,
            "owner_id": user.id,
            "parent_id": None,
            "ai_reply_enabled": True
        },
        {
            "wechat_id": "wxid_789012",
            "nickname": "次要账号",
            "remark": "个人微信",
            "is_group": False,
            "avatar": None,
            "owner_id": user.id,
            "parent_id": None,
            "ai_reply_enabled": True
        }
    ]
    
    created_accounts = []
    for account_data in accounts:
        account = db.query(WechatContact).filter(
            WechatContact.wechat_id == account_data["wechat_id"],
            WechatContact.owner_id == user.id,
            WechatContact.parent_id == None
        ).first()
        
        if not account:
            account = WechatContact(**account_data)
            db.add(account)
            created_accounts.append(account)
    
    if created_accounts:
        db.commit()
        print(f"已创建 {len(created_accounts)} 个微信账号")
    
    return db.query(WechatContact).filter(
        WechatContact.owner_id == user.id,
        WechatContact.parent_id == None
    ).all()

def create_contacts(accounts, strategies):
    """为每个账号创建联系人"""
    all_contacts = []
    
    for account in accounts:
        friends = [
            {
                "wechat_id": f"wxid_friend{i}",
                "nickname": f"好友{i}",
                "remark": f"备注{i}",
                "is_group": False,
                "avatar": None,
                "owner_id": account.owner_id,
                "parent_id": account.id,
                "ai_reply_enabled": True,
                "ai_strategy_id": random.choice(strategies).id if strategies else None
            }
            for i in range(1, 6)  # 每个账号5个好友
        ]
        
        groups = [
            {
                "wechat_id": f"wxid_group{i}",
                "nickname": f"群聊{i}",
                "remark": f"群组{i}",
                "is_group": True,
                "avatar": None,
                "owner_id": account.owner_id,
                "parent_id": account.id,
                "ai_reply_enabled": True,
                "ai_strategy_id": random.choice(strategies).id if strategies else None
            }
            for i in range(1, 4)  # 每个账号3个群组
        ]
        
        contacts = friends + groups
        created_contacts = []
        
        for contact_data in contacts:
            contact = db.query(WechatContact).filter(
                WechatContact.wechat_id == contact_data["wechat_id"],
                WechatContact.parent_id == account.id
            ).first()
            
            if not contact:
                contact = WechatContact(**contact_data)
                db.add(contact)
                created_contacts.append(contact)
        
        if created_contacts:
            db.commit()
            print(f"已为账号 {account.nickname} 创建 {len(created_contacts)} 个联系人")
            all_contacts.extend(created_contacts)
    
    return all_contacts

def create_messages(contacts):
    """为联系人创建消息记录"""
    messages_data = []
    
    for contact in contacts:
        num_messages = random.randint(5, 10)
        
        for i in range(num_messages):
            is_from_ai = random.choice([True, False])
            
            days_ago = random.randint(0, 7)
            hours_ago = random.randint(0, 23)
            minutes_ago = random.randint(0, 59)
            created_at = datetime.now() - timedelta(days=days_ago, hours=hours_ago, minutes=minutes_ago)
            
            if is_from_ai:
                content = random.choice([
                    "这是一条AI自动回复的消息。",
                    "您好，有什么可以帮助您的吗？",
                    "感谢您的咨询，我们会尽快处理。",
                    "您的问题已记录，稍后会有人联系您。",
                    "请问还有其他需要了解的信息吗？"
                ])
                sender_id = "AI助手"
            else:
                content = random.choice([
                    "你好，请问这个产品有什么特点？",
                    "我想了解一下价格。",
                    "什么时候能发货？",
                    "有没有优惠活动？",
                    "可以帮我查询一下订单状态吗？",
                    "谢谢你的帮助！"
                ])
                sender_id = contact.wechat_id
            
            message_data = {
                "contact_id": contact.id,
                "sender_id": sender_id,
                "content": content,
                "content_type": "text",
                "is_from_ai": is_from_ai,
                "status": "sent",
                "created_at": created_at
            }
            
            messages_data.append(message_data)
    
    created_messages = []
    for message_data in messages_data:
        message = WechatMessage(**message_data)
        db.add(message)
        created_messages.append(message)
    
    if created_messages:
        db.commit()
        print(f"已创建 {len(created_messages)} 条消息")

def main():
    try:
        create_tables()
        
        test_user = create_test_user()
        
        strategies = create_ai_strategies()
        
        accounts = create_wechat_accounts(test_user)
        
        contacts = create_contacts(accounts, strategies)
        
        create_messages(contacts)
        
        print("测试数据创建完成！")
        print("可以使用以下账号登录测试：")
        print("用户名: test")
        print("密码: test")
        
    except Exception as e:
        db.rollback()
        print(f"创建测试数据失败: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    main()
