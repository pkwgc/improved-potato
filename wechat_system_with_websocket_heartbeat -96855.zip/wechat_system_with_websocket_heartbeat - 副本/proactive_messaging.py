import json
import logging
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from database import (
    User, WechatContact, ProactiveMessage, Template, 
    IntentTracking, get_db
)

logger = logging.getLogger(__name__)

class ProactiveMessagingService:
    """主动消息服务"""
    
    def __init__(self, socketio=None):
        self.socketio = socketio
        self.message_templates = {
            "关怀": "您好{name}，最近怎么样？有什么需要帮助的吗？",
            "营销": "Hi {name}，我们有新的优惠活动，{product}现在特价，您要了解一下吗？",
            "复购提醒": "亲爱的{name}，您上次购买的{product}用得怎么样？需要再来一份吗？",
            "节日问候": "{name}，{festival}快乐！我们为您准备了特别优惠！"
        }
    
    def generate_personalized_message(self, db: Session, contact_id: int, message_type: str) -> str:
        """生成个性化消息"""
        try:
            contact = db.query(WechatContact).filter(WechatContact.id == contact_id).first()
            if not contact:
                return ""
            
            user = db.query(User).filter(User.id == contact.owner_id).first()
            if not user:
                return ""
            
            customer_name = contact.nickname or contact.remark or "朋友"
            
            recent_intent = db.query(IntentTracking).filter(
                IntentTracking.contact_id == contact_id
            ).order_by(IntentTracking.detected_at.desc()).first()
            
            template = self.message_templates.get(message_type, "您好{name}，有什么可以帮助您的吗？")
            
            message = template.format(
                name=customer_name,
                product="我们的产品",
                festival="节日"
            )
            
            if user.value_level == "高价值":
                message += " 作为我们的VIP客户，您享有专属优惠！"
            elif recent_intent and recent_intent.intent_type == "高意向":
                message += " 我看您之前对我们的产品很感兴趣，有什么问题可以随时问我。"
            
            return message
            
        except Exception as e:
            logger.error(f"生成个性化消息失败: {str(e)}")
            return "您好，有什么可以帮助您的吗？"
    
    def schedule_proactive_message(self, db: Session, contact_id: int, message_type: str, 
                                 scheduled_time: datetime = None):
        """安排主动消息"""
        try:
            contact = db.query(WechatContact).filter(WechatContact.id == contact_id).first()
            if not contact or contact.follow_disabled_by_user:
                return False
            
            if not contact.auto_follow_enabled:
                return False
            
            content = self.generate_personalized_message(db, contact_id, message_type)
            
            if not scheduled_time:
                if contact.follow_frequency == "daily":
                    scheduled_time = datetime.now() + timedelta(days=1)
                elif contact.follow_frequency == "weekly":
                    scheduled_time = datetime.now() + timedelta(weeks=1)
                elif contact.follow_frequency == "monthly":
                    scheduled_time = datetime.now() + timedelta(days=30)
                else:
                    scheduled_time = datetime.now() + timedelta(days=1)
            
            proactive_msg = ProactiveMessage(
                contact_id=contact_id,
                message_type=message_type,
                content=content,
                scheduled_time=scheduled_time,
                status='pending'
            )
            
            db.add(proactive_msg)
            db.commit()
            
            logger.info(f"已安排主动消息: 联系人ID={contact_id}, 类型={message_type}, 时间={scheduled_time}")
            return True
            
        except Exception as e:
            logger.error(f"安排主动消息失败: {str(e)}")
            return False
    
    def send_pending_messages(self, db: Session):
        """发送待发送的主动消息"""
        try:
            pending_messages = db.query(ProactiveMessage).filter(
                ProactiveMessage.status == 'pending',
                ProactiveMessage.scheduled_time <= datetime.now()
            ).all()
            
            for msg in pending_messages:
                success = self._send_message_via_websocket(msg)
                if success:
                    msg.status = 'sent'
                    msg.sent_time = datetime.now()
                    
                    contact = db.query(WechatContact).filter(WechatContact.id == msg.contact_id).first()
                    if contact:
                        contact.last_follow_time = datetime.now()
                else:
                    msg.status = 'failed'
            
            db.commit()
            logger.info(f"处理了 {len(pending_messages)} 条待发送消息")
            
        except Exception as e:
            logger.error(f"发送待发送消息失败: {str(e)}")
    
    def _send_message_via_websocket(self, message: ProactiveMessage) -> bool:
        """通过WebSocket发送消息"""
        try:
            if not self.socketio:
                return False
            
            contact = message.contact
            if not contact:
                return False
            
            message_data = {
                "type": "proactive_message",
                "content": message.content,
                "content_type": "text",
                "sender": {"id": "system", "name": "系统"},
                "receiver": {"id": contact.wechat_id, "name": contact.nickname or contact.remark},
                "timestamp": datetime.now().isoformat(),
                "require_ack": True
            }
            
            room_name = f"wechat_{contact.wechat_id}"
            self.socketio.emit('new_message', message_data, room=room_name)
            
            logger.info(f"已通过WebSocket发送主动消息: 房间={room_name}")
            return True
            
        except Exception as e:
            logger.error(f"通过WebSocket发送消息失败: {str(e)}")
            return False
    
    def check_and_schedule_follow_ups(self, db: Session):
        """检查并安排跟进消息"""
        try:
            contacts = db.query(WechatContact).filter(
                WechatContact.auto_follow_enabled == True,
                WechatContact.follow_disabled_by_user == False
            ).all()
            
            for contact in contacts:
                if self._should_send_follow_up(contact):
                    message_type = self._determine_message_type(db, contact)
                    self.schedule_proactive_message(db, contact.id, message_type)
            
        except Exception as e:
            logger.error(f"检查跟进消息失败: {str(e)}")
    
    def _should_send_follow_up(self, contact: WechatContact) -> bool:
        """判断是否应该发送跟进消息"""
        if not contact.last_follow_time:
            return True
        
        now = datetime.now()
        time_diff = now - contact.last_follow_time
        
        if contact.follow_frequency == "daily" and time_diff.days >= 1:
            return True
        elif contact.follow_frequency == "weekly" and time_diff.days >= 7:
            return True
        elif contact.follow_frequency == "monthly" and time_diff.days >= 30:
            return True
        
        return False
    
    def _determine_message_type(self, db: Session, contact: WechatContact) -> str:
        """确定消息类型"""
        if contact.customer_type == "成交客户":
            return "复购提醒"
        elif contact.customer_type == "高意向客户":
            return "营销"
        else:
            return "关怀"
