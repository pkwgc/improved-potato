import json
import re
import logging
from typing import Dict, Any, Tuple
from response_validator import ResponseValidator
from intent_classifier import IntentClassifier

logger = logging.getLogger(__name__)

class TestAIService:
    """用于测试的AI服务类，移除了数据库依赖"""
    
    def __init__(self, api_key: str = "test_key", base_url: str = "test_url"):
        """初始化测试AI服务"""
        self.api_key = api_key
        self.base_url = base_url
        self.response_validator = ResponseValidator()
        self.intent_classifier = IntentClassifier()
        logger.info("测试AIService初始化成功")
    
    def extract_reply_and_confidence(self, content: str) -> Tuple[str, float, Dict[str, Any]]:
        """从AI回复中提取回复内容、置信度和意图信息，使用标准化格式"""
        try:
            json_content = None
            try:
                json.loads(content)
                json_content = content
                logger.info("输入内容本身是有效的JSON")
            except json.JSONDecodeError:
                match = re.search(r'```json\s*({[\s\S]*?})\s*```', content, re.DOTALL)
                if match:
                    json_content = match.group(1)
                else:
                    match = re.search(r'{[\s\S]*?}', content, re.DOTALL)
                    if match:
                        json_content = match.group(0)
            
            if json_content:
                json_str = re.sub(r'(?<!\\)\\(?![\\/"bfnrtu])', r'\\\\', json_content)
                try:
                    parsed = json.loads(json_str)
                    logger.info(f"成功解析JSON响应: {json.dumps(parsed, ensure_ascii=False)[:200]}...")
                    
                    validated_response = self.response_validator.fix_response(parsed)
                    
                    reply = validated_response.get("reply", content)
                    intent_type = validated_response.get("intent_type", "no_intent")
                    intent_details = validated_response.get("intent_details", {})
                    confidence = intent_details.get("confidence", 0.0)
                    user_info = validated_response.get("user_info_detected", {})
                    order_info = validated_response.get("order_info")
                    
                    if intent_type == "specific_intent":
                        intent_name = intent_details.get("name")
                        entities = intent_details.get("entities", {})
                        
                        trigger_api = False
                        api_name = ""
                        
                        if intent_name in ["下单", "查询库存", "查询价格", "查询订单"]:
                            trigger_api = True
                            api_name = f"{intent_name}_api"
                        
                        intent_data = {
                            "trigger_api": trigger_api,
                            "intent": intent_name,
                            "industry": "",  # 可以从其他地方获取
                            "api": api_name,
                            "slots": entities,
                            "confidence": confidence,
                            "user_info": user_info,
                            "intent_type": intent_type
                        }
                        
                        if order_info:
                            intent_data["order_info"] = order_info
                        
                        if trigger_api:
                            logger.info(f"检测到用户明确意图: {json.dumps(intent_data, ensure_ascii=False)[:200]}...")
                    else:
                        intent_data = {
                            "trigger_api": False,
                            "intent_type": intent_type,
                            "user_info": user_info
                        }
                        
                        if intent_type == "casual_chat":
                            logger.info("检测到用户闲聊")
                        else:
                            logger.info("未检测到明确意图")
                    
                    return reply, confidence, intent_data
                except json.JSONDecodeError as e:
                    logger.warning(f"JSON解析失败: {str(e)}")
            
            logger.warning("未找到有效的JSON响应，创建默认响应格式")
            reply = content
            confidence = 0.0
            
            intent_data = {
                "trigger_api": False,
                "intent_type": "no_intent",
                "user_info": {}
            }
            
            logger.info("返回默认无意图响应")
                
        except Exception as e:
            logger.warning(f"reply/confidence/intent 提取失败：{e}")
            reply = content
            confidence = 0.0
            intent_data = {"trigger_api": False, "intent_type": "no_intent"}
            
        return reply, confidence, intent_data
