import os
import logging
from datetime import datetime
from database import get_db, User, WechatContact, WechatMessage, AIStrategy, create_tables

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_demo_data():
    try:
        os.environ['USE_SQLITE'] = 'true'  # 确保使用SQLite
        
        # 创建表（如果不存在）
        create_tables()
        
        # 获取数据库连接
        db = next(get_db())
        
        # 创建演示用户（如果不存在）
        user = db.query(User).filter(User.user_id == 'demo_user').first()
        if not user:
            user = User(
                user_id="demo_user",
                username="演示用户",
                password="demo123",  # 实际应用中应该哈希处理
                is_admin=False,
                token_limit=0,
                token_balance=5000
            )
            db.add(user)
            db.flush()
            logger.info("成功创建演示用户账户")
        
        # 创建演示AI策略（如果不存在）
        strategy = db.query(AIStrategy).filter(AIStrategy.name == '默认策略').first()
        if not strategy:
            strategy = AIStrategy(
                name="默认策略",
                description="用于演示的默认AI回复策略",
                prompt_template="你是专业的客服，请回答用户的问题: {user_input}",
                system_message="作为一个专业的客服助手，你应该礼貌、简洁地回答用户问题。",
                temperature=0.7,
                max_tokens=2000
            )
            db.add(strategy)
            db.flush()
            logger.info("成功创建演示AI策略")
        
        wechat_accounts = [
            {
                "wechat_id": "wxid_demo1",
                "nickname": "演示微信1",
                "is_group": False
            },
            {
                "wechat_id": "wxid_demo2",
                "nickname": "演示微信2",
                "is_group": False
            }
        ]
        
        created_accounts = []
        for account_data in wechat_accounts:
            account = db.query(WechatContact).filter(
                WechatContact.wechat_id == account_data["wechat_id"],
                WechatContact.owner_id == user.id,
                WechatContact.is_group == False
            ).first()
            
            if not account:
                account = WechatContact(
                    wechat_id=account_data["wechat_id"],
                    nickname=account_data["nickname"],
                    owner_id=user.id,
                    is_group=False
                )
                db.add(account)
                db.flush()
                created_accounts.append(account)
        
        if created_accounts:
            logger.info(f"成功创建 {len(created_accounts)} 个演示微信账号")
        
        # 创建演示联系人（如果不存在）
        contacts_data = [
            {
                "wechat_id": "friend001",
                "nickname": "张三",
                "remark": "老张",
                "is_group": False,
                "avatar": None,
                "ai_reply_enabled": True,
                "account_id": "wxid_demo1"
            },
            {
                "wechat_id": "friend002",
                "nickname": "李四",
                "remark": "老李",
                "is_group": False,
                "avatar": None,
                "ai_reply_enabled": False,
                "account_id": "wxid_demo1"
            },
            {
                "wechat_id": "group001",
                "nickname": "项目组",
                "remark": "工作群",
                "is_group": True,
                "avatar": None,
                "ai_reply_enabled": True,
                "account_id": "wxid_demo1"
            },
            {
                "wechat_id": "friend003",
                "nickname": "王五",
                "remark": "老王",
                "is_group": False,
                "avatar": None,
                "ai_reply_enabled": True,
                "account_id": "wxid_demo2"
            },
            {
                "wechat_id": "friend004",
                "nickname": "赵六",
                "remark": "老赵",
                "is_group": False,
                "avatar": None,
                "ai_reply_enabled": False,
                "account_id": "wxid_demo2"
            }
        ]
        
        created_contacts = []
        for contact_data in contacts_data:
            account_id = contact_data.pop("account_id")
            account = db.query(WechatContact).filter(
                WechatContact.wechat_id == account_id,
                WechatContact.owner_id == user.id
            ).first()
            
            if not account:
                continue
                
            contact = db.query(WechatContact).filter(
                WechatContact.wechat_id == contact_data["wechat_id"],
                WechatContact.owner_id == user.id
            ).first()
            
            if not contact:
                contact = WechatContact(
                    wechat_id=contact_data["wechat_id"],
                    nickname=contact_data["nickname"],
                    remark=contact_data["remark"],
                    is_group=contact_data["is_group"],
                    avatar=contact_data["avatar"],
                    ai_reply_enabled=contact_data["ai_reply_enabled"],
                    owner_id=user.id,
                    ai_strategy_id=strategy.id if contact_data["ai_reply_enabled"] else None
                )
                db.add(contact)
                db.flush()
                created_contacts.append(contact)
        
        if created_contacts:
            logger.info(f"成功创建 {len(created_contacts)} 个演示联系人")
            
            # 为第一个联系人添加一些示例消息
            if len(created_contacts) > 0:
                messages = [
                    {
                        "sender_id": user.user_id,
                        "content": "你好，这是一条测试消息",
                        "is_from_ai": False
                    },
                    {
                        "sender_id": created_contacts[0].wechat_id,
                        "content": "你好，收到了你的消息",
                        "is_from_ai": False
                    },
                    {
                        "sender_id": user.user_id,
                        "content": "这个系统支持实时消息推送吗？",
                        "is_from_ai": False
                    },
                    {
                        "sender_id": created_contacts[0].wechat_id,
                        "content": "是的，支持WebSocket实时推送，无需客户端轮询。",
                        "is_from_ai": True
                    }
                ]
                
                for msg_data in messages:
                    message = WechatMessage(
                        contact_id=created_contacts[0].id,
                        sender_id=msg_data["sender_id"],
                        content=msg_data["content"],
                        is_from_ai=msg_data["is_from_ai"],
                        content_type="text",
                        created_at=datetime.utcnow()
                    )
                    db.add(message)
                
                logger.info(f"成功创建示例消息")
        
        db.commit()
        logger.info("演示数据创建完成")
        
    except Exception as e:
        logger.error(f"创建演示数据失败: {str(e)}")

if __name__ == "__main__":
    create_demo_data()
