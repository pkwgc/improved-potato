import json
from user_profile_extractor import update_user_profile_from_message
from database import User, get_db, engine, Base

def setup_test_db():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    
    test_engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(test_engine)
    TestSession = sessionmaker(bind=test_engine)
    return TestSession()

def test_ai_json_extraction():
    db = setup_test_db()
    
    test_user = User(user_id="test_user", username="测试用户")
    db.add(test_user)
    db.commit()
    
    print("=== 测试1: 有明确意图的JSON (购买意图) ===")
    intent_json = {
        "reply": "龙井这就备好\\地址记下啦\\明天让你闻见茶香",
        "trigger_api": True,
        "intent": "购买",
        "industry": "茶叶",
        "api": "purchase",
        "slots": {
            "tea_type": "西湖龙井",
            "amount": "2斤",
            "address": "海南省海口市龙华区城西商务中心1101",
            "contact": "李庭皇",
            "phone": "15203699059"
        },
        "confidence": 0.95
    }
    
    test_message = "帮我来2斤龙井，地址：海南省海口市龙华区城西商务中心1101，李庭皇，15203699059"
    
    update_user_profile_from_message(db, "test_user", test_message, intent_json)
    
    updated_user = db.query(User).filter(User.user_id == "test_user").first()
    print(f"用户资料: {updated_user.profile_data}")
    
    print("\n=== 测试2: 用户提供重要信息的JSON ===")
    user_info_json = {
        "reply": "已记录您的信息，感谢分享",
        "trigger_api": False,
        "user_info": {
            "name": "阿杰",
            "phone": "13988889999",
            "address": "广州市天河区珠江新城123号"
        },
        "user_preferences": {
            "flavor": "花香型",
            "tea_types": ["龙井", "小种"],
            "usage_scenario": ["自饮"],
            "gift_packaging": False,
            "chat_style": "幽默有趣"
        }
    }
    
    test_message2 = "我叫阿杰，喜欢花香型的茶，特别是龙井和小种，平时自己喝，不需要礼品包装。我住在广州市天河区珠江新城123号，电话是13988889999"
    
    update_user_profile_from_message(db, "test_user", test_message2, user_info_json)
    
    updated_user = db.query(User).filter(User.user_id == "test_user").first()
    print(f"用户身份: {updated_user.identity}")
    print(f"用户爱好: {updated_user.hobbies}")
    print(f"用户资料: {updated_user.profile_data}")
    
    print("\n=== 测试3: 无意图的JSON ===")
    no_intent_json = {
        "reply": "很高兴认识您，有什么可以帮到您的吗？",
        "trigger_api": False
    }
    
    test_message3 = "你好，我是一名医生，平时喜欢喝茶"
    
    update_user_profile_from_message(db, "test_user", test_message3, no_intent_json)
    
    updated_user = db.query(User).filter(User.user_id == "test_user").first()
    print(f"用户身份: {updated_user.identity}")
    print(f"用户爱好: {updated_user.hobbies}")
    print(f"用户资料: {updated_user.profile_data}")

if __name__ == "__main__":
    test_ai_json_extraction()
