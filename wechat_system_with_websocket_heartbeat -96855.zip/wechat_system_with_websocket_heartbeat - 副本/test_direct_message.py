"""
WebSocket直接消息测试脚本
用于测试WebSocket直接消息发送功能
"""
import socketio
import time
import logging
import json
from datetime import datetime

logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DirectMessageTester:
    def __init__(self, server_url, user_id, wechat_id, contact_id):
        self.server_url = server_url
        self.user_id = user_id
        self.wechat_id = wechat_id
        self.contact_id = contact_id
        self.sio = socketio.Client()
        self.connected = False
        self.authenticated = False
        self.setup_event_handlers()
        
    def setup_event_handlers(self):
        """设置事件处理器"""
        @self.sio.on('connect')
        def on_connect():
            """连接成功事件"""
            self.connected = True
            logger.info(f"已连接到服务器: {self.server_url}")
            self.authenticate()
            
        @self.sio.on('disconnect')
        def on_disconnect():
            """断开连接事件"""
            self.connected = False
            self.authenticated = False
            logger.info("与服务器断开连接")
            
        @self.sio.on('auth_success')
        def on_auth_success(data):
            """认证成功事件"""
            logger.info(f"认证成功: {data}")
            self.authenticated = True
            self.sio.emit('join', {'user_id': self.user_id})
            self.join_wechat_room()
        
        @self.sio.on('joined_wechat_room')
        def on_joined_wechat_room(data):
            """加入微信房间事件"""
            logger.info(f"已加入微信房间: {data}")
            wechat_id = data.get('wechat_id')
            if wechat_id:
                logger.info(f"成功加入微信账号 {wechat_id} 的房间")
                self.send_test_message()
        
        @self.sio.on('message_sent')
        def on_message_sent(data):
            """消息发送成功事件"""
            logger.info(f"消息发送成功: {data}")
            message_id = data.get('message_id')
            if message_id:
                logger.info(f"消息ID: {message_id}")
        
        @self.sio.on('new_message')
        def on_new_message(data):
            """接收新消息事件"""
            logger.info(f"收到新消息: {data}")
            if data.get('id') and data.get('require_ack', False):
                self.acknowledge_message(data.get('id'))
        
        @self.sio.on('error')
        def on_error(data):
            """错误事件"""
            logger.error(f"收到错误: {data}")
            if data.get('code') == 'auth_required':
                logger.info("尝试重新认证")
                self.authenticate()
    
    def authenticate(self):
        """向服务器发送认证信息"""
        logger.info(f"发送认证信息: user_id={self.user_id}")
        self.sio.emit('authenticate', {'user_id': self.user_id})
        
    def join_wechat_room(self):
        """加入微信账号房间"""
        logger.info(f"请求加入微信账号 {self.wechat_id} 的房间")
        self.sio.emit('join_wechat_room', {
            'user_id': self.user_id,
            'wechat_id': self.wechat_id
        })
            
    def send_test_message(self):
        """发送测试消息"""
        logger.info(f"发送测试消息到联系人 {self.contact_id}")
        self.sio.emit('send_direct_message', {
            'user_id': self.user_id,
            'wechat_id': self.wechat_id,
            'contact_id': self.contact_id,
            'content': f"测试消息 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            'content_type': 'text'
        })
        
    def acknowledge_message(self, message_id):
        """确认消息已接收"""
        logger.info(f"确认消息: {message_id}")
        self.sio.emit('message_ack', {
            'user_id': self.user_id,
            'message_id': message_id
        })
    
    def connect(self):
        """连接到WebSocket服务器"""
        try:
            logger.info(f"正在连接到服务器: {self.server_url}")
            self.sio.connect(self.server_url)
        except Exception as e:
            logger.error(f"连接失败: {str(e)}")
            return False
        return True
    
    def disconnect(self):
        """断开与WebSocket服务器的连接"""
        if self.connected:
            logger.info("正在断开连接")
            self.sio.disconnect()
    
    def run(self, duration=30):
        """运行测试一段时间"""
        if not self.connect():
            return
        
        try:
            start_time = time.time()
            while time.time() - start_time < duration:
                if self.connected and self.authenticated:
                    self.send_test_message()
                time.sleep(10)
        except KeyboardInterrupt:
            logger.info("用户中断，正在退出")
        finally:
            self.disconnect()

if __name__ == "__main__":
    tester = DirectMessageTester(
        server_url='http://localhost:5000', 
        user_id='test_user_123',
        wechat_id='test_wechat_id',
        contact_id='friend1'
    )
    tester.run(duration=30)  # 运行30秒
