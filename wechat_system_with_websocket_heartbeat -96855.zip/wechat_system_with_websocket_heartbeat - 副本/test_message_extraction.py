import json
from user_profile_extractor import extract_user_profile_info, analyze_message_intent, extract_order_info

def test_message_extraction():
    """测试从用户消息中提取用户资料信息"""
    
    print("=== 测试1: 提取订单信息 ===")
    test_messages = [
        "帮我来2斤龙井，地址：海南省海口市龙华区城西商务中心1101，李庭皇，15203699059",
        "我要订购5斤铁观音，收货地址是北京市朝阳区建国路88号，联系人王小明，电话13812345678",
        "请帮我邮寄普洱茶3饼，送到上海市浦东新区张江高科技园区，收件人：张三，13987654321",
        "我的地址是广州市天河区体育西路123号，我叫李四，电话是13500001111，麻烦送2盒大红袍"
    ]
    
    for i, msg in enumerate(test_messages):
        print(f"\n消息 {i+1}: {msg}")
        order_info = extract_order_info(msg)
        print(f"提取的订单信息: {json.dumps(order_info, ensure_ascii=False, indent=2)}")
    
    print("\n=== 测试2: 提取身份信息 ===")
    identity_messages = [
        "我是一名医生，平时工作很忙",
        "作为一名教师，我很关注教育质量",
        "我在一家IT公司工作，是软件工程师",
        "我是大学生，正在学习计算机专业"
    ]
    
    for i, msg in enumerate(identity_messages):
        print(f"\n消息 {i+1}: {msg}")
        profile_info = extract_user_profile_info(msg)
        print(f"提取的身份信息: {profile_info.get('identity', '未提取到')}")
    
    print("\n=== 测试3: 提取爱好信息 ===")
    hobby_messages = [
        "我平时喜欢打篮球和游泳",
        "我的爱好是摄影，经常去各地拍照",
        "我喜欢阅读，特别是历史类书籍",
        "我的兴趣爱好包括旅游、品茶和听音乐"
    ]
    
    for i, msg in enumerate(hobby_messages):
        print(f"\n消息 {i+1}: {msg}")
        profile_info = extract_user_profile_info(msg)
        print(f"提取的爱好信息: {profile_info.get('hobbies', '未提取到')}")
    
    print("\n=== 测试4: 提取综合信息 ===")
    mixed_messages = [
        "我叫王明，是一名医生，平时喜欢喝茶和看书，我住在北京市海淀区",
        "我是李华，在上海工作，是一名教师，爱好旅游和摄影，电话13912345678",
        "大家好，我是张三，今年35岁，是一名工程师，平时喜欢打篮球和游泳"
    ]
    
    for i, msg in enumerate(mixed_messages):
        print(f"\n消息 {i+1}: {msg}")
        profile_info = extract_user_profile_info(msg)
        print(f"提取的综合信息: {json.dumps(profile_info, ensure_ascii=False, indent=2)}")
        
    print("\n=== 测试5: 意图识别 ===")
    intent_messages = [
        "我是一名医生，平时工作很忙",
        "帮我来2斤龙井，地址：海南省海口市龙华区城西商务中心1101",
        "今天天气真好",
        "我叫王明，是一名医生，平时喜欢喝茶和看书"
    ]
    
    for i, msg in enumerate(intent_messages):
        print(f"\n消息 {i+1}: {msg}")
        has_intent = analyze_message_intent(msg)
        print(f"是否包含信息分享意图: {has_intent}")

if __name__ == "__main__":
    test_message_extraction()
