import json
import logging
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from database import Base, User
from user_profile_extractor import update_user_profile_from_message

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def setup_test_db():
    """创建内存数据库用于测试"""
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    return Session()

def test_slots_extraction():
    """测试从AI响应JSON中的slots字段提取用户信息"""
    db = setup_test_db()
    
    test_user = User(user_id="pk_wgc", username="pk_wgc")
    db.add(test_user)
    db.commit()
    
    user_message = "帮我来2斤龙井，地址：海南省海口市龙华区城西商务中心1101，李庭皇，15203699059"
    
    ai_response = {
        "reply": "龙井这就备好\\地址记下啦\\明天让你闻见茶香",
        "trigger_api": True,
        "intent": "购买",
        "industry": "茶叶",
        "api": "order_processing",
        "slots": {
            "tea_type": "西湖龙井",
            "amount": "2斤",
            "address": "海南省海口市龙华区城西商务中心1101",
            "name": "李庭皇",
            "phone": "15203699059"
        },
        "confidence": 1.0
    }
    
    logger.info("开始测试从slots提取用户信息")
    result = update_user_profile_from_message(db, "pk_wgc", user_message, ai_response)
    
    updated_user = db.query(User).filter(User.user_id == "pk_wgc").first()
    logger.info(f"更新结果: {result}")
    logger.info(f"用户身份: {updated_user.identity}")
    logger.info(f"用户爱好: {updated_user.hobbies}")
    logger.info(f"用户资料: {updated_user.profile_data}")
    
    if updated_user.profile_data:
        profile_data = json.loads(updated_user.profile_data)
        logger.info(f"联系信息: {json.dumps(profile_data.get('contact_info', {}), ensure_ascii=False, indent=2)}")
        logger.info(f"偏好信息: {json.dumps(profile_data.get('preferences', {}), ensure_ascii=False, indent=2)}")

def test_user_info_extraction():
    """测试从AI响应JSON中的user_info和user_preferences字段提取用户信息"""
    db = setup_test_db()
    
    test_user = User(user_id="test_user", username="测试用户")
    db.add(test_user)
    db.commit()
    
    user_message = "我叫阿杰，喜欢花香型的茶，特别是龙井和小种，平时自己喝，不需要礼品包装。我住在广州市天河区珠江新城123号，电话是13988889999"
    
    ai_response = {
        "reply": "已记录您的信息，感谢分享",
        "trigger_api": False,
        "user_info": {
            "name": "阿杰",
            "phone": "13988889999",
            "address": "广州市天河区珠江新城123号"
        },
        "user_preferences": {
            "flavor": "花香型",
            "tea_types": ["龙井", "小种"],
            "usage_scenario": ["自饮"],
            "gift_packaging": False,
            "chat_style": "幽默有趣"
        }
    }
    
    logger.info("\n开始测试从user_info和user_preferences提取用户信息")
    result = update_user_profile_from_message(db, "test_user", user_message, ai_response)
    
    updated_user = db.query(User).filter(User.user_id == "test_user").first()
    logger.info(f"更新结果: {result}")
    logger.info(f"用户身份: {updated_user.identity}")
    logger.info(f"用户爱好: {updated_user.hobbies}")
    logger.info(f"用户资料: {updated_user.profile_data}")
    
    if updated_user.profile_data:
        profile_data = json.loads(updated_user.profile_data)
        logger.info(f"联系信息: {json.dumps(profile_data.get('contact_info', {}), ensure_ascii=False, indent=2)}")
        logger.info(f"偏好信息: {json.dumps(profile_data.get('preferences', {}), ensure_ascii=False, indent=2)}")

if __name__ == "__main__":
    test_slots_extraction()
    test_user_info_extraction()
