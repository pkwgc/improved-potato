import json
import re
import time
import logging
import sys
import hashlib
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from openai import OpenAI
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy.orm import Session
from datetime import datetime
from database import User, Template, Context, BillingRecord, Industry, save_context_to_db, record_billing, save_chat_message
from intent_recognition import recognize_intent
from intent_classifier import IntentClassifier
from response_validator import ResponseValidator

logger = logging.getLogger(__name__)
if not logger.hasHandlers():
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(handler)

TEMPLATE_CACHE: Dict[str, Dict[str, Any]] = {}
RESPONSE_CACHE: Dict[str, Dict[str, Any]] = {}
MAX_CACHE_SIZE = 100

class AIService:
    def __init__(self, api_key: str, base_url: str = "https://api.deepseek.com", 
                 model: str = "deepseek-chat", max_tokens: int = 1024, 
                 temperature: float = 0.7):
        """初始化AI服务
        
        Args:
            api_key: API密钥
            base_url: API基础URL
            model: 模型名称
            max_tokens: 最大生成token数量
            temperature: 温度参数
        """
        import httpx
        http_client = httpx.Client(timeout=30.0)  # 减少超时时间以提高响应速度
        self.client = OpenAI(api_key=api_key, base_url=base_url, http_client=http_client)
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.executor = ThreadPoolExecutor(max_workers=5)  # 创建线程池用于并行处理
        self.response_validator = ResponseValidator()  # 初始化响应验证器
        self.intent_classifier = IntentClassifier()  # 初始化意图分类器
        logger.info(f"AIService初始化成功: model={model}, max_tokens={max_tokens}, temperature={temperature}")

    def process_chat(
            self, db: Session, user_id: str, user_message: str,
            template_name: str, username: Optional[str] = None,
            prompt_override: Optional[str] = None
    ) -> Dict[str, Any]:
        """处理聊天请求"""

        start_time = time.time()
        # 参数校验
        if not all([db, user_id, user_message, template_name]):
            logger.error("参数缺失：db, user_id, user_message, template_name 必须提供")
            return {"error": "参数错误", "trigger_api": False}

        try:
            logger.info(f"[process_chat] user_id={user_id}, content={user_message}, time={datetime.now().isoformat()}")

            industry_name = self._get_industry_name(db, template_name)
            intent_result = recognize_intent(db, user_message, industry_name)
            if intent_result.get("trigger_api"):
                return self._handle_intent_reply(db, user_id, user_message, intent_result)

            chat_contexts = self._load_context(db, user_id, template_name)
            chat_contexts.append({"role": "user", "content": str(user_message)})
            chat_contexts = self._clean_context(chat_contexts)
            chat_contexts = self._trim_context(chat_contexts)  # 增加裁剪，防止太长

            base_prompt = prompt_override or self._get_template_with_cache(db, template_name, user_id)
            import json
            from config import AI_RESPONSE_FORMAT, fill_placeholders

            ai_response_template = self._get_ai_response_format_template(db)
            response_format_instruction = fill_placeholders(ai_response_template, {
                "ai_response_format": json.dumps(AI_RESPONSE_FORMAT, ensure_ascii=False, indent=2)
            })
            user_prompt = base_prompt + "\n\n" + response_format_instruction

            from config import ENABLE_USER_PROFILE
            if ENABLE_USER_PROFILE and user_id:
                user_prompt = self._replace_user_profile_placeholders(db, user_prompt, user_id)

            cache_key = self._generate_cache_key(user_prompt, chat_contexts, user_id)
            cached_response = self._check_cache(cache_key)
            if cached_response:
                return self._handle_cache_hit(
                    db, user_id, username, user_message, template_name,
                    chat_contexts, cached_response, start_time
                )

            # token 校验
            user_obj = db.query(User).filter(User.user_id == user_id).first()
            if user_obj and user_obj.token_balance <= 0:
                logger.warning(f"用户 {user_id} 余额不足")
                return {"error": "余额不足，请充值", "trigger_api": False}

            ai_reply_result = self._call_ai_and_parse(
                user_prompt, chat_contexts, user_message, db, user_id,
                username, template_name, start_time, user_obj
            )
            return ai_reply_result

        except ValueError as ve:
            logger.error(f"参数异常: {ve}")
            return {"error": f"参数异常: {ve}", "trigger_api": False}
        except ConnectionError as ce:
            logger.error(f"AI连接失败: {ce}")
            return {"error": f"AI连接失败: {ce}", "trigger_api": False}
        except Exception as e:
            logger.error(f"未知异常: {e}")
            return {"error": f"AI服务错误: {e}", "trigger_api": False}

    # ===================== 辅助函数 =====================

    def _trim_context(self, chat_contexts, max_len=15):
        """限制上下文长度，防止消息过长影响AI消耗"""
        if len(chat_contexts) > max_len:
            return chat_contexts[-max_len:]
        return chat_contexts

    def _handle_cache_hit(
            self, db, user_id, username, user_message, template_name,
            chat_contexts, cached_response, start_time
    ):
        logger.info(f"缓存命中: {str(cached_response)[:60]}...")

        # 数据库和计费流水仍写（如需只读缓存，可改为可选项）
        context = save_context_to_db(
            db, user_id, template_name,
            chat_contexts + [{"role": "assistant", "content": cached_response["reply"]}],
            username
        )
        user_obj = db.query(User).filter(User.user_id == user_id).first()
        if user_obj and context:
            save_chat_message(db, context.id, user_obj.id, "user", user_message)
            save_chat_message(db, context.id, user_obj.id, "assistant", cached_response["reply"])

        tokens_used = cached_response.get("tokens_used", 100)
        if user_obj:
            user_obj.token_balance = max(0, user_obj.token_balance - tokens_used)
            db.commit()
        record_billing(db, user_id, tokens_used, time.time() - start_time, template_name)

        # 返回结构
        response = {
            "reply": cached_response["reply"],
            "raw_content": cached_response.get("raw_content", "")
        }
        intent_data = cached_response.get("intent_data", {})
        if intent_data.get("trigger_api", False):
            response.update({
                "confidence": cached_response.get("confidence", 0),
                "trigger_api": True,
                "intent": intent_data.get("intent", ""),
                "industry": intent_data.get("industry", ""),
                "api": intent_data.get("api", ""),
                "slots": intent_data.get("slots", {}),
                "intent_type": "specific_intent"
            })
            if "user_info" in intent_data:
                response["user_info"] = intent_data["user_info"]
            if "order_info" in intent_data:
                response["order_info"] = intent_data["order_info"]
        else:
            response.update({
                "trigger_api": False,
                "intent_type": intent_data.get("intent_type", "no_intent"),
                "confidence": cached_response.get("confidence", 0)
            })
        return response

    def _call_ai_and_parse(
            self, user_prompt, chat_contexts, user_message, db, user_id,
            username, template_name, start_time, user_obj
    ):
        try:
            import json
            ai_messages = [{'role': 'system', 'content': user_prompt}] + chat_contexts
            logger.info("[AI] 即将发送：%s", json.dumps(ai_messages, ensure_ascii=False, indent=2))

            future = self.executor.submit(
                self.client.chat.completions.create,
                model=self.model,
                messages=ai_messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                stream=False
            )
            response = future.result()
            result = response.model_dump()
            if not (result.get("choices") and result["choices"][0]["message"].get("content")):
                logger.error("API响应无效: %s", result)
                return {"error": "API响应无效", "trigger_api": False}

            content = result["choices"][0]["message"]["content"]
            reply, confidence, intent_data = self.extract_reply_and_confidence(content)

            if intent_data.get("trigger_api", False) or intent_data.get("user_info", {}):
                intent_data["user_message"] = user_message
                self._save_important_user_info(db, user_id, intent_data)

            context = save_context_to_db(
                db, user_id, template_name,
                chat_contexts + [{"role": "assistant", "content": reply}],
                username
            )
            if user_obj and context:
                save_chat_message(db, context.id, user_obj.id, "user", user_message)
                save_chat_message(db, context.id, user_obj.id, "assistant", reply)

            tokens_used = result.get("usage", {}).get("total_tokens", 0)
            if user_obj:
                user_obj.token_balance = max(0, user_obj.token_balance - tokens_used)
                db.commit()
            record_billing(db, user_id, tokens_used, time.time() - start_time, template_name)

            # 写入缓存
            self._update_cache(self._generate_cache_key(user_prompt, chat_contexts, user_id), {
                "reply": reply,
                "confidence": confidence,
                "raw_content": content,
                "tokens_used": tokens_used,
                "timestamp": time.time(),
                "intent_data": intent_data
            })

            logger.info(f"AI回复成功: user_id={user_id}, tokens={tokens_used}, time={time.time() - start_time:.2f}s")

            response_data = {
                "reply": reply,
                "raw_content": content
            }
            if intent_data.get("trigger_api", False):
                response_data.update({
                    "confidence": confidence,
                    "trigger_api": True,
                    "intent": intent_data.get("intent", ""),
                    "industry": intent_data.get("industry", ""),
                    "api": intent_data.get("api", ""),
                    "slots": intent_data.get("slots", {}),
                    "intent_type": "specific_intent"
                })
                if "user_info" in intent_data:
                    response_data["user_info"] = intent_data["user_info"]
                if "order_info" in intent_data:
                    response_data["order_info"] = intent_data["order_info"]
            else:
                response_data.update({
                    "trigger_api": False,
                    "intent_type": intent_data.get("intent_type", "no_intent")
                })
            return response_data
        except Exception as e:
            logger.error(f"AI调用出错: {e}")
            return {"error": f"AI调用失败: {e}", "trigger_api": False}

    def _generate_cache_key(self, prompt: str, contexts: List[Dict[str, str]], user_id: str) -> str:
        """生成缓存键"""
        data = {
            "prompt": prompt,
            "contexts": contexts,
            "user_id": user_id
        }
        data_str = json.dumps(data, sort_keys=True)
        key = hashlib.md5(data_str.encode()).hexdigest()
        return key
    
    def _check_cache(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """检查缓存中是否有响应"""
        if cache_key in RESPONSE_CACHE:
            if time.time() - RESPONSE_CACHE[cache_key].get("timestamp", 0) < 86400:
                return RESPONSE_CACHE[cache_key]
            else:
                del RESPONSE_CACHE[cache_key]
        return None
    
    def _update_cache(self, cache_key: str, response: Dict[str, Any]) -> None:
        """更新缓存"""
        if len(RESPONSE_CACHE) >= MAX_CACHE_SIZE:
            oldest_key = min(RESPONSE_CACHE.keys(), key=lambda k: RESPONSE_CACHE[k].get("timestamp", 0))
            del RESPONSE_CACHE[oldest_key]
        
        RESPONSE_CACHE[cache_key] = response

    @lru_cache(maxsize=32)
    def _get_template_with_cache(self, db: Session, template_name: str, user_id: Optional[str] = None) -> str:
        """获取模板内容，使用缓存提高性能"""
        import pdb;
        pdb.set_trace()


        template = db.query(Template).filter(Template.name == template_name).first()
        if not template:
            logger.error(f"[模板错误] 模板未找到：{template_name}，请在后台管理界面创建该模板")
            return f"错误：模板 '{template_name}' 未找到，请联系管理员在后台创建该模板。"

        cache = TEMPLATE_CACHE.get(template_name)
        if cache and cache["updated_at"] == str(template.updated_at):
            template_content = cache["content"]
        else:
            template_content = template.content
            TEMPLATE_CACHE[template_name] = {
                "content": template_content,
                "updated_at": str(template.updated_at)
            }
            logger.warning(f"[缓存刷新] 模板：{template_name} 内容已更新，重新缓存")
        
        from config import ENABLE_USER_PROFILE, USER_PROFILE_PLACEHOLDER_PREFIX, USER_PROFILE_PLACEHOLDER_SUFFIX
        from config import ENABLE_PERSONALIZED_PROMPT, PERSONALIZED_PROMPT_TEMPLATE
        
        if ENABLE_USER_PROFILE and user_id:
            template_content = self._replace_user_profile_placeholders(db, template_content, user_id)
        
        if ENABLE_PERSONALIZED_PROMPT and user_id:
            try:
                user_data = self._get_user_data_for_personalized_prompt(db, user_id)
                
                industry_name = self._get_industry_name(db, template_name)
                if industry_name:
                    user_data["行业"] = industry_name
                
                from database import User
                import json
                user = db.query(User).filter(User.user_id == user_id).first()
                
                from config import USER_PROFILE_PLACEHOLDER_PREFIX as prefix, USER_PROFILE_PLACEHOLDER_SUFFIX as suffix
                
                user_info_parts = []
                
                
                if user_data.get("兴趣"):
                    user_info_parts.append(f"兴趣爱好：{user_data['兴趣']}")
                    logger.info(f"添加用户兴趣爱好：{user_data['兴趣']}")
                
                if user and hasattr(user, 'profile_data') and user.profile_data:
                    try:
                        profile = json.loads(user.profile_data)
                        if "contact_info" in profile and "address" in profile["contact_info"]:
                            address = profile["contact_info"]["address"]
                            if address:
                                user_info_parts.append(f"收货地址：{address}")
                                logger.info(f"添加用户收货地址：{address}")
                        if "important_info" in profile and profile["important_info"]:
                            recent_important_info = profile["important_info"][-5:]  # 只取最近5条重要信息
                            important_info_text = []
                            for info in recent_important_info:
                                info_text = f"- {info.get('timestamp', '')}: {info.get('intent', '')} ({info.get('industry', '')})"
                                if info.get('slots'):
                                    slots_text = ", ".join([f"{k}={v}" for k, v in info['slots'].items()])
                                    info_text += f" [{slots_text}]"
                                important_info_text.append(info_text)
                            
                            if important_info_text:
                                user_info_parts.append(f"用户重要信息：\n" + "\n".join(important_info_text))
                                logger.info(f"添加用户重要信息：{len(recent_important_info)}条")
                    except Exception as e:
                        logger.error(f"解析用户收货地址失败: {str(e)}")
                
                inventory_info = user_data.get("product_inventory", "")
                detailed_inventory_info = user_data.get("detailed_product_inventory", "")
                
                if inventory_info:
                    user_info_parts.append(f"库存信息摘要：{inventory_info}")
                    logger.info(f"添加用户库存摘要：{inventory_info[:100]}...")
                    
                if detailed_inventory_info:
                    user_info_parts.append(f"库存详细信息：\n{detailed_inventory_info}\n请严格只推荐以上库存商品，不要虚构或猜测不存在的产品。")
                    logger.info(f"添加用户详细库存信息成功")
                
                logger.info("主动添加用户信息到提示词中，无论模板中是否有占位符")
                
                if user_info_parts:
                    user_info_section = "\n\n# 用户信息\n" + "\n".join(user_info_parts)
                    
                    if "# 任务" in template_content:
                        task_parts = template_content.split("# 任务", 1)
                        task_header = task_parts[0] + "# 任务"
                        task_content = task_parts[1]
                        template_content = task_header + task_content + user_info_section
                    else:
                        template_content = template_content + user_info_section
                    
                    logger.info(f"[添加用户信息] {user_info_section[:100]}...")
                else:
                    logger.info("用户没有额外信息，使用原始模板")
            except Exception as e:
                logger.error(f"处理个性化提示词出错: {str(e)}")
        
        return template_content

    def _get_ai_response_format_template(self, db: Session) -> str:
        """获取AI响应格式模板"""
        template = db.query(Template).filter(
            Template.template_type == "ai_response_format"
        ).first()
        
        if not template:
            logger.error("AI响应格式模板未找到，请在后台管理界面创建 'ai_response_format' 类型的模板")
            return "错误：AI响应格式模板未找到，请联系管理员创建AI响应格式模板。"
        
        return template.content
        
    @lru_cache(maxsize=32)
    def _get_user_data_for_personalized_prompt(self, db: Session, user_id: str) -> Dict[str, Any]:
        """获取用户数据用于个性化提示词，使用缓存提高性能"""
        user_data = {}
        
        user = db.query(User).filter(User.user_id == user_id).first()
        if not user:
            logger.warning(f"获取用户数据失败: 用户不存在 (user_id={user_id})")
            return user_data
            
        user_data["name"] = user.username or "未知用户"
        
        if hasattr(user, 'identity') and user.identity:
            user_data["行业"] = user.identity
        else:
            user_data["行业"] = ""
            
        if hasattr(user, 'hobbies') and user.hobbies:
            user_data["兴趣"] = user.hobbies
        else:
            user_data["兴趣"] = ""
        
        user_data["最近购买"] = ""
        
        if hasattr(user, 'profile_data') and user.profile_data:
            try:
                import json
                profile = json.loads(user.profile_data)
                
                if "preferences" in profile and "recent_purchases" in profile["preferences"]:
                    recent_purchases = profile["preferences"].get("recent_purchases", [])
                    if isinstance(recent_purchases, list) and recent_purchases:
                        user_data["最近购买"] = "、".join(recent_purchases)
            except Exception as e:
                logger.error(f"解析用户资料JSON数据失败: {str(e)}")
        
        try:
            from inventory_processor import get_user_inventory_from_db
            inventory_data = get_user_inventory_from_db(db, user_id)
            if inventory_data:
                user_data["product_inventory"] = inventory_data.get("summary", "")
                
                items = inventory_data.get("items", [])
                if items:
                    detailed_inventory = []
                    for item in items:
                        item_detail = f"{item.get('产品名称', '未知商品')}: {item.get('库存数量', 0)}件"
                        if item.get('单价'):
                            item_detail += f", 单价{item.get('单价')}元"
                        if item.get('备注'):
                            item_detail += f", 备注: {item.get('备注')}"
                        detailed_inventory.append(item_detail)
                    
                    user_data["detailed_product_inventory"] = "\n".join(detailed_inventory)
                    logger.info(f"添加用户详细库存信息成功，共{len(items)}件商品")
                
                logger.info(f"获取到用户库存数据: {user_data['product_inventory'][:100]}...")
            else:
                user_data["product_inventory"] = ""
                user_data["detailed_product_inventory"] = ""
                logger.warning(f"用户没有库存数据: {user_id}")
        except Exception as e:
            logger.error(f"获取用户库存数据失败: {str(e)}")
            user_data["product_inventory"] = ""
            user_data["detailed_product_inventory"] = ""
            
        return user_data

    @lru_cache(maxsize=32)
    def _get_industry_name(self, db: Session, template_name: str) -> Optional[str]:
        """获取模板对应的行业名称，使用缓存提高性能"""
        template = db.query(Template).filter(Template.name == template_name).first()
        if template and template.industry_id:
            industry = db.query(Industry).filter(Industry.id == template.industry_id).first()
            return industry.name if industry else None
        return None

    def _handle_intent_reply(self, db, user_id, user_message, intent_result):
        """处理意图识别结果"""
        tokens_used = len(user_message) + 100
        user = db.query(User).filter(User.user_id == user_id).first()
        if user:
            if user.token_balance <= 0:
                return {"intent": None, "confidence": 0, "usage": {"total_tokens": 0}}
            user.token_balance = max(0, user.token_balance - tokens_used)
            db.commit()
        record_billing(db, user_id, tokens_used=tokens_used)
        return intent_result

    def extract_reply_and_confidence(self, content: str) -> Tuple[str, float, Dict[str, Any]]:
        """从AI回复中提取回复内容、置信度和意图信息，使用标准化格式"""
        try:
            json_content = None
            match = re.search(r'```json\s*({[\s\S]*?})\s*```', content, re.DOTALL)
            if match:
                json_content = match.group(1)
            else:
                match = re.search(r'{[\s\S]*?}', content, re.DOTALL)
                if match:
                    json_content = match.group(0)
            
            if json_content:
                json_str = re.sub(r'(?<!\\)\\(?![\\/"bfnrtu])', r'\\\\', json_content)
                try:
                    parsed = json.loads(json_str)
                    logger.info(f"成功解析JSON响应: {json.dumps(parsed, ensure_ascii=False)[:200]}...")
                    
                    validated_response = self.response_validator.fix_response(parsed)
                    
                    reply = validated_response.get("reply", content)
                    intent_type = validated_response.get("intent_type", "no_intent")
                    intent_details = validated_response.get("intent_details", {})
                    confidence = intent_details.get("confidence", 0.0)
                    user_info = validated_response.get("user_info_detected", {})
                    order_info = validated_response.get("order_info")
                    
                    if user_info:
                        logger.info(f"检测到用户重要信息: {json.dumps(user_info, ensure_ascii=False, indent=2)}")
                        logger.info(f"用户信息类型: {', '.join(user_info.keys())}")
                        logger.info(f"用户信息详情: {json.dumps(user_info, ensure_ascii=False)}")
                    
                    if intent_type == "specific_intent":
                        intent_name = intent_details.get("name")
                        entities = intent_details.get("entities", {})
                        
                        trigger_api = False
                        api_name = ""
                        
                        if intent_name in ["下单", "查询库存", "查询价格", "查询订单"]:
                            trigger_api = True
                            api_name = f"{intent_name}_api"
                        
                        intent_data = {
                            "trigger_api": trigger_api,
                            "intent": intent_name,
                            "industry": "",  # 可以从其他地方获取
                            "api": api_name,
                            "slots": entities,
                            "confidence": confidence,
                            "user_info": user_info,
                            "intent_type": intent_type
                        }
                        
                        if order_info:
                            intent_data["order_info"] = order_info
                        
                        if trigger_api:
                            logger.info(f"检测到用户明确意图: {json.dumps(intent_data, ensure_ascii=False)[:200]}...")
                    else:
                        intent_data = {
                            "trigger_api": False,
                            "intent_type": intent_type,
                            "user_info": user_info
                        }
                        
                        if intent_type == "casual_chat":
                            logger.info("检测到用户闲聊")
                        else:
                            logger.info("未检测到明确意图")
                    
                    return reply, confidence, intent_data
                except json.JSONDecodeError as e:
                    logger.warning(f"JSON解析失败: {str(e)}")
            
            logger.warning("未找到有效的JSON响应，创建默认响应格式")
            reply = content
            confidence = 0.0
            
            intent_data = {
                "trigger_api": False,
                "intent_type": "no_intent",
                "user_info": {}
            }
            
            logger.info("返回默认无意图响应")
                
        except Exception as e:
            logger.warning(f"reply/confidence/intent 提取失败：{e}")
            reply = content
            confidence = 0.0
            intent_data = {"trigger_api": False, "intent_type": "no_intent"}
            
        return reply, confidence, intent_data

    def _load_context(self, db: Session, user_id: str, template_name: str) -> List[Dict[str, str]]:
        """加载用户上下文"""
        from database import load_context_from_db
        contexts = load_context_from_db(db, user_id, template_name)
        return contexts or []

    def _clean_context(self, contexts: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """优化的上下文清理，保持在合理长度并合并相似查询，应用时间衰减和意图冲突处理"""
        from config import MAX_CONTEXT_MESSAGES
        import re
        import time
        from datetime import datetime
        
        contexts = [msg for msg in contexts if msg["role"] in ["user", "assistant"]]
        
        if len(contexts) <= MAX_CONTEXT_MESSAGES * 2:
            return self._apply_time_decay(contexts)
        
        intent_keywords = {
            "下单": ["购买", "下单", "买", "订购"],
            "查询库存": ["库存", "有货", "还有吗"],
            "查询价格": ["多少钱", "价格", "价钱"],
            "查询订单": ["订单", "物流", "发货"]
        }
        
        latest_intent_msgs = {}
        
        merged_contexts = []
        i = 0
        while i < len(contexts):
            current_msg = contexts[i]
            
            current_intent = None
            if current_msg["role"] == "user":
                for intent, keywords in intent_keywords.items():
                    if any(keyword in current_msg["content"] for keyword in keywords):
                        current_intent = intent
                        break
            
            if current_intent and i + 1 < len(contexts):
                latest_intent_msgs[current_intent] = {
                    "index": i,
                    "msg": current_msg,
                    "response": contexts[i + 1] if i + 1 < len(contexts) else None
                }
                
                has_conflict = False
                product_match = re.search(r'([\u4e00-\u9fa5]+茶|[\u4e00-\u9fa5]+)', current_msg["content"])
                if product_match:
                    product = product_match.group(1)
                    for intent, data in latest_intent_msgs.items():
                        if intent != current_intent:
                            other_msg = data["msg"]
                            other_product_match = re.search(r'([\u4e00-\u9fa5]+茶|[\u4e00-\u9fa5]+)', other_msg["content"])
                            if other_product_match and other_product_match.group(1) == product:
                                if data["index"] < i:
                                    has_conflict = True
                                    logger.info(f"检测到意图冲突: {intent} vs {current_intent} 对于产品 {product}")
                                    break
                
                if has_conflict:
                    i += 2
                    continue
            
            if current_msg["role"] == "user" and i + 2 < len(contexts):
                next_user_msg = contexts[i + 2]
                if next_user_msg["role"] == "user":
                    similarity = self._similarity(current_msg["content"], next_user_msg["content"])
                    if similarity > 0.7:
                        logger.info(f"合并相似消息，相似度: {similarity:.2f}")
                        i += 2  # 跳过当前的回复和下一个相似的问题
                        continue
            
            merged_contexts.append(current_msg)
            i += 1
        
        if len(merged_contexts) > MAX_CONTEXT_MESSAGES * 2:
            merged_contexts = merged_contexts[-(MAX_CONTEXT_MESSAGES * 2):]
        
        return self._apply_time_decay(merged_contexts)
    
    def _apply_time_decay(self, contexts: List[Dict[str, str]]) -> List[Dict[str, str]]:
        """应用时间衰减权重，减少旧消息的影响"""
        if not contexts:
            return []
        
        weighted_contexts = []
        for i, msg in enumerate(contexts):
            position_weight = (i + 1) / len(contexts)
            time_weight = 0.5 + 0.5 * position_weight
            
            msg_copy = msg.copy()
            
            if msg["role"] == "user" and i < len(contexts) - 2:
                original_content = msg["content"]
                
                if original_content.startswith("[权重:"):
                    try:
                        end_pos = original_content.find("]")
                        if end_pos > 0:
                            original_content = original_content[end_pos + 1:].lstrip()
                    except Exception as e:
                        logger.warning(f"移除权重标记时出错: {str(e)}")
                
                msg_copy["content"] = f"[权重:{time_weight:.2f}] {original_content}"
            
            weighted_contexts.append(msg_copy)
        
        return weighted_contexts
    
    def _similarity(self, text1: str, text2: str) -> float:
        """计算两个文本的简单相似度"""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        
        return len(intersection) / len(union)
        
    def _replace_user_profile_placeholders(self, db: Session, template_content: str, user_id: str) -> str:
        """替换模板中的用户资料占位符 - 使用统一的占位符替换函数"""
        from config import fill_placeholders, USER_PROFILE_PLACEHOLDER_PREFIX as prefix, USER_PROFILE_PLACEHOLDER_SUFFIX as suffix
        from config import CUSTOM_PLACEHOLDERS
        from database import User
        import json
        
        user = db.query(User).filter(User.user_id == user_id).first()
        if not user:
            return template_content
        
        params = {}
        
        if user.user_id:
            params["user_id"] = user.user_id
        if user.username:
            params["username"] = user.username
            params["name"] = user.username
            params["用户名"] = user.username
        
        if hasattr(user, 'identity') and user.identity:
            params["identity"] = user.identity
            params["行业"] = user.identity
        
        if hasattr(user, 'hobbies') and user.hobbies:
            params["hobbies"] = user.hobbies
            params["兴趣"] = user.hobbies
        
        if hasattr(user, 'recent_purchases') and user.recent_purchases:
            params["最近购买"] = user.recent_purchases
        try:
            from inventory_processor import get_user_inventory_from_db
            inventory_data = get_user_inventory_from_db(db, user_id)
            if inventory_data:
                params["product_inventory"] = inventory_data.get("summary", "暂无库存数据")
            else:
                params["product_inventory"] = "暂无库存数据"
        except Exception as e:
            logger.error(f"获取用户库存数据失败: {str(e)}")
            params["product_inventory"] = "暂无库存数据"
        
        if hasattr(user, 'profile_data') and user.profile_data:
            try:
                profile = json.loads(user.profile_data)
                
                if "contact_info" in profile:
                    contact_info = profile["contact_info"]
                    for key, value in contact_info.items():
                        params[f"contact_{key}"] = str(value)
                    
                    if "address" in contact_info and contact_info["address"]:
                        params["收货地址"] = contact_info["address"]
                
                if "preferences" in profile:
                    preferences = profile["preferences"]
                    for key, value in preferences.items():
                        params[f"pref_{key}"] = str(value)
                    
                    if "recent_purchases" in preferences:
                        recent_purchases = preferences.get("recent_purchases", [])
                        if isinstance(recent_purchases, list) and recent_purchases:
                            params["最近购买"] = "、".join(recent_purchases)
                
                for key, value in profile.items():
                    if key not in ["contact_info", "preferences"]:
                        params[f"profile_{key}"] = str(value)
            except Exception as e:
                logger.error(f"解析用户资料JSON数据失败: {str(e)}")
        
        try:
            custom_placeholders = json.loads(CUSTOM_PLACEHOLDERS)
            if isinstance(custom_placeholders, list):
                for placeholder in custom_placeholders:
                    name = placeholder.get('name', '')
                    default_value = placeholder.get('default', '')
                    if name:
                        value = default_value
                        if hasattr(user, 'profile_data') and user.profile_data:
                            try:
                                profile = json.loads(user.profile_data)
                                if name in profile:
                                    value = str(profile[name])
                            except:
                                pass
                        params[name] = value
        except Exception as e:
            logger.error(f"处理自定义占位符失败: {str(e)}")
        
        return fill_placeholders(template_content, params)
    
    def _save_important_user_info(self, db: Session, user_id: str, intent_data: Dict[str, Any]) -> None:
        """保存用户的重要信息，包括意图信息和用户个人信息"""
        try:
            user = db.query(User).filter(User.user_id == user_id).first()
            if not user:
                logger.warning(f"用户不存在: {user_id}")
                return
            
            profile_data = {}
            if hasattr(user, 'profile_data') and user.profile_data:
                try:
                    profile_data = json.loads(user.profile_data)
                except Exception as e:
                    logger.error(f"解析用户profile_data失败: {str(e)}")
            
            if "important_info" not in profile_data:
                profile_data["important_info"] = []
            
            message_content = intent_data.get("message", "")
            if not message_content:
                if "user_message" in intent_data:
                    message_content = intent_data["user_message"]
                elif "content" in intent_data:
                    message_content = intent_data["content"]
            
            if message_content and message_content.startswith("[权重:"):
                logger.info(f"检测到带权重标记的消息，跳过保存: {message_content[:50]}...")
                return
            
            user_info = intent_data.get("user_info", {})
            if user_info:
                logger.info(f"检测到用户重要信息: {json.dumps(user_info, ensure_ascii=False, indent=2)}")
                
                has_new_info = False
                
                if "name" in user_info and (
                    "name" not in profile_data or profile_data["name"] != user_info["name"]
                ):
                    profile_data["name"] = user_info["name"]
                    logger.info(f"更新用户姓名: {user_info['name']}")
                    has_new_info = True
                
                if "phone" in user_info and (
                    "phone" not in profile_data or profile_data["phone"] != user_info["phone"]
                ):
                    profile_data["phone"] = user_info["phone"]
                    logger.info(f"更新用户电话: {user_info['phone']}")
                    has_new_info = True
                
                if "address" in user_info:
                    if "contact_info" not in profile_data:
                        profile_data["contact_info"] = {}
                        has_new_info = True
                    elif "address" not in profile_data["contact_info"] or profile_data["contact_info"]["address"] != user_info["address"]:
                        has_new_info = True
                    
                    if has_new_info:
                        profile_data["contact_info"]["address"] = user_info["address"]
                        logger.info(f"更新用户地址: {user_info['address']}")
                
                if "interests" in user_info:
                    if "interests" not in profile_data:
                        profile_data["interests"] = []
                        has_new_info = True
                    
                    for interest in user_info["interests"]:
                        if interest not in profile_data["interests"]:
                            profile_data["interests"].append(interest)
                            has_new_info = True
                    
                    if has_new_info:
                        logger.info(f"更新用户兴趣: {user_info['interests']}")
                
                if "preferences" in user_info:
                    if "preferences" not in profile_data:
                        profile_data["preferences"] = {}
                        has_new_info = True
                    
                    for key, value in user_info["preferences"].items():
                        if key not in profile_data["preferences"] or profile_data["preferences"][key] != value:
                            profile_data["preferences"][key] = value
                            has_new_info = True
                    
                    if has_new_info:
                        logger.info(f"更新用户偏好: {user_info['preferences']}")
                
                is_duplicate = False
                if not has_new_info and profile_data["important_info"]:
                    recent_records = profile_data["important_info"][-5:] if profile_data["important_info"] else []
                    
                    for record in recent_records:
                        if record.get("type") == "user_info_update":
                            record_data = record.get("data", {})
                            similarity = self._calculate_user_info_similarity(record_data, user_info)
                            
                            try:
                                record_time = datetime.strptime(record.get("timestamp", ""), "%Y-%m-%d %H:%M:%S")
                                current_time = datetime.now()
                                time_diff_minutes = (current_time - record_time).total_seconds() / 60
                            except Exception as e:
                                logger.error(f"时间解析失败: {str(e)}")
                                time_diff_minutes = 999
                            
                            if similarity > 0.8 and time_diff_minutes < 30:
                                is_duplicate = True
                                logger.info(f"检测到重复的用户信息，跳过保存，相似度: {similarity:.2f}, 时间差: {time_diff_minutes:.1f}分钟")
                                break
                
                if has_new_info or not is_duplicate:
                    user_info_record = {
                        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "type": "user_info_update",
                        "data": user_info
                    }
                    profile_data["important_info"].append(user_info_record)
                    logger.info(f"记录用户信息更新: {json.dumps(user_info_record, ensure_ascii=False)}")
                else:
                    logger.info("用户信息无变化或为重复信息，跳过记录")
            
            if intent_data.get("trigger_api", False):
                current_intent = intent_data.get("intent", "")
                current_industry = intent_data.get("industry", "")
                current_api = intent_data.get("api", "")
                current_slots = intent_data.get("slots", {})
                
                is_duplicate = False
                recent_records = profile_data["important_info"][-10:] if profile_data["important_info"] else []
                
                for record in recent_records:
                    if record.get("type") == "intent_record":
                        intent_match = record.get("intent", "") == current_intent
                        industry_match = record.get("industry", "") == current_industry
                        
                        api_similar = False
                        record_api = record.get("api", "")
                        if record_api and current_api:
                            if record_api == current_api or (
                                "_" in record_api and "_" in current_api and 
                                record_api.split("_")[0] == current_api.split("_")[0]
                            ):
                                api_similar = True
                        
                        if intent_match and industry_match and api_similar:
                            record_slots = record.get("slots", {})
                            slots_similarity = self._calculate_slots_similarity(record_slots, current_slots)
                            
                            try:
                                record_time = datetime.strptime(record.get("timestamp", ""), "%Y-%m-%d %H:%M:%S")
                                current_time = datetime.now()
                                time_diff_minutes = (current_time - record_time).total_seconds() / 60
                            except Exception as e:
                                logger.error(f"时间解析失败: {str(e)}")
                                time_diff_minutes = 999  # 如果时间解析失败，设置一个大值
                            
                            if slots_similarity > 0.7 and time_diff_minutes < 30:
                                is_duplicate = True
                                logger.info(f"检测到重复的意图记录，跳过保存: {current_intent} ({current_industry}), 相似度: {slots_similarity:.2f}, 时间差: {time_diff_minutes:.1f}分钟")
                                break
                
                if not is_duplicate:
                    intent_record = {
                        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "type": "intent_record",
                        "intent": current_intent,
                        "industry": current_industry,
                        "api": current_api,
                        "slots": current_slots,
                        "confidence": intent_data.get("confidence", 0)
                    }
                    
                    profile_data["important_info"].append(intent_record)
                    logger.info(f"保存用户意图记录: {json.dumps(intent_record, ensure_ascii=False)}")
            
            user.profile_data = json.dumps(profile_data, ensure_ascii=False)
            db.commit()
            logger.info(f"用户资料更新成功: {user_id}")
            logger.info(f"当前用户资料: {json.dumps(profile_data, ensure_ascii=False, indent=2)}")
            
        except Exception as e:
            logger.error(f"保存用户重要信息失败: {str(e)}")
            db.rollback()
            
    def _calculate_slots_similarity(self, slots1: Dict[str, Any], slots2: Dict[str, Any]) -> float:
        """计算两个slots字典的相似度"""
        if not slots1 and not slots2:
            return 1.0  # 两个都为空，完全相同
            
        if not slots1 or not slots2:
            return 0.0  # 一个为空一个不为空，完全不同
        
        all_keys = set(slots1.keys()).union(set(slots2.keys()))
        if not all_keys:
            return 1.0
            
        common_keys = set(slots1.keys()).intersection(set(slots2.keys()))
        
        same_value_count = 0
        for key in common_keys:
            if str(slots1[key]) == str(slots2[key]):
                same_value_count += 1
                
        return (same_value_count / len(all_keys))
        
    def _calculate_user_info_similarity(self, info1: Dict[str, Any], info2: Dict[str, Any]) -> float:
        """计算两个用户信息字典的相似度"""
        if not info1 and not info2:
            return 1.0  # 两个都为空，完全相同
            
        if not info1 or not info2:
            return 0.0  # 一个为空一个不为空，完全不同
        
        normalized_info1 = self._normalize_user_info(info1)
        normalized_info2 = self._normalize_user_info(info2)
        
        key_fields = {
            "name": 0.3,
            "phone": 0.3,
            "address": 0.2,
            "interests": 0.1,
            "preferences": 0.1
        }
        
        total_weight = 0.0
        similarity_score = 0.0
        
        for field, weight in key_fields.items():
            if field in normalized_info1 and field in normalized_info2:
                total_weight += weight
                
                if field in ["name", "phone", "address"]:
                    if str(normalized_info1[field]) == str(normalized_info2[field]):
                        similarity_score += weight
                
                elif field == "interests":
                    if isinstance(normalized_info1[field], list) and isinstance(normalized_info2[field], list):
                        set1 = set(normalized_info1[field])
                        set2 = set(normalized_info2[field])
                        if set1 or set2:  # 避免除以零
                            intersection = len(set1.intersection(set2))
                            union = len(set1.union(set2))
                            similarity_score += weight * (intersection / union)
                
                elif field == "preferences":
                    if isinstance(normalized_info1[field], dict) and isinstance(normalized_info2[field], dict):
                        nested_similarity = self._calculate_slots_similarity(normalized_info1[field], normalized_info2[field])
                        similarity_score += weight * nested_similarity
        
        if total_weight == 0:
            return 0.0
            
        return similarity_score / total_weight
    
    def _normalize_user_info(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """标准化用户信息结构，处理不同格式的数据"""
        normalized = {}
        
        if "name" in info:
            normalized["name"] = info["name"]
        if "phone" in info:
            normalized["phone"] = info["phone"]
        if "address" in info:
            normalized["address"] = info["address"]
        if "interests" in info:
            normalized["interests"] = info["interests"]
        if "preferences" in info:
            normalized["preferences"] = info["preferences"]
        
        if "contact_info" in info:
            contact = info["contact_info"]
            if "name" in contact:
                normalized["name"] = contact["name"]
            if "phone" in contact:
                normalized["phone"] = contact["phone"]
            if "address" in contact:
                normalized["address"] = contact["address"]
        
        if "contact" in info:
            contact = info["contact"]
            if "name" in contact:
                normalized["name"] = contact["name"]
            if "phone" in contact:
                normalized["phone"] = contact["phone"]
            if "address" in contact:
                normalized["address"] = contact["address"]
        
        if "preference" in info:
            if "preferences" not in normalized:
                normalized["preferences"] = {}
            normalized["preferences"]["favorite_tea"] = info["preference"]
        
        return normalized
