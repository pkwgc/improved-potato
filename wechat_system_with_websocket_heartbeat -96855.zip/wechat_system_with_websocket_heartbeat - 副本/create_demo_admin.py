import os
import logging
from database import get_db, User, create_tables

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_demo_admin():
    try:
        os.environ['USE_SQLITE'] = 'true'  # 确保使用SQLite
        
        # 创建表（如果不存在）
        create_tables()
        
        # 获取数据库连接
        db = next(get_db())
        
        # 检查演示管理员是否已存在
        admin = db.query(User).filter(User.username == 'demo_admin').first()
        if admin:
            logger.info("演示管理员账户已存在")
            return
            
        # 创建演示管理员
        admin = User(
            user_id="demo_admin",
            username="演示管理员",
            password="demo123",  # 实际应用中应该哈希处理
            is_admin=True,
            token_limit=0,
            token_balance=10000
        )
        db.add(admin)
        db.commit()
        logger.info("成功创建演示管理员账户")
        
    except Exception as e:
        logger.error(f"创建演示管理员失败: {str(e)}")

if __name__ == "__main__":
    create_demo_admin()
