import logging
import re
from typing import Dict, Any, Optional, List

logger = logging.getLogger(__name__)

class IntentClassifier:
    """意图分类器，用于识别用户意图"""
    
    def __init__(self):
        self.intent_patterns = {
            "查询库存": ["库存", "有货", "还有吗", "剩余", "存货"],
            "下单": ["买", "购买", "下单", "订购", "要", "来"],
            "查询价格": ["多少钱", "价格", "价钱", "售价", "怎么卖"],
            "查询订单": ["订单", "发货", "物流", "快递", "什么时候到"],
            "提供地址": ["地址", "送到", "收货地址", "邮寄到"],
            "闲聊": ["天气", "你好", "在吗", "最近怎么样", "聊聊天"]
        }
        
        self.entity_patterns = {
            "product": r"([\u4e00-\u9fa5]+茶|[\u4e00-\u9fa5]+)",
            "quantity": r"(\d+)(包|盒|斤|克|个|件|箱)",
            "address": r"([^，。！？,.!?]*?(?:省|市|区|县|路|街|号)[^，。！？,.!?]*)",
            "phone": r"(1[3-9]\d{9})",
            "name": r"(?:收件人|联系人|收货人)[:：]?\s*([^，。！？,.!?0-9]{2,5})"
        }
    
    def classify_intent(self, text: str, context: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """分类用户意图"""
        intent_scores = {}
        for intent, keywords in self.intent_patterns.items():
            score = sum(1 for keyword in keywords if keyword in text)
            if score > 0:
                intent_scores[intent] = score
        
        if not intent_scores:
            return {
                "intent_type": "no_intent",
                "intent_details": {
                    "name": None,
                    "confidence": 0.0,
                    "entities": {}
                }
            }
        
        best_intent = max(intent_scores.items(), key=lambda x: x[1])
        intent_name = best_intent[0]
        confidence = min(best_intent[1] / 3.0, 1.0)  # 简单的置信度计算
        
        entities = self._extract_entities(text, intent_name)
        
        if intent_name == "闲聊":
            intent_type = "casual_chat"
        else:
            intent_type = "specific_intent"
        
        return {
            "intent_type": intent_type,
            "intent_details": {
                "name": intent_name,
                "confidence": confidence,
                "entities": entities
            }
        }
    
    def _extract_entities(self, text: str, intent_name: str) -> Dict[str, Any]:
        """提取实体信息"""
        entities = {}
        
        if intent_name in ["查询库存", "下单", "查询价格"]:
            product_match = re.search(self.entity_patterns["product"], text)
            if product_match:
                entities["product"] = product_match.group(1)
            
            quantity_match = re.search(self.entity_patterns["quantity"], text)
            if quantity_match:
                entities["quantity"] = int(quantity_match.group(1))
                entities["unit"] = quantity_match.group(2)
        
        if intent_name == "提供地址":
            address_match = re.search(self.entity_patterns["address"], text)
            if address_match:
                entities["address"] = address_match.group(1)
            
            phone_match = re.search(self.entity_patterns["phone"], text)
            if phone_match:
                entities["phone"] = phone_match.group(1)
            
            name_match = re.search(self.entity_patterns["name"], text)
            if name_match:
                entities["name"] = name_match.group(1)
        
        return entities
    
    def enhance_with_context(self, intent_result: Dict[str, Any], context: List[Dict[str, Any]]) -> Dict[str, Any]:
        """使用上下文增强意图识别结果"""
        if not context:
            return intent_result
        
        if intent_result["intent_details"]["confidence"] < 0.5:
            for msg in reversed(context[-3:]):  # 只检查最近3条消息
                if msg.get("intent_type") == "specific_intent":
                    intent_result["intent_details"]["confidence"] += 0.2
                    break
        
        return intent_result
