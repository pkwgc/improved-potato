#!/usr/bin/env python3
import os
import sys
import json
import requests
import unittest
from unittest.mock import patch, MagicMock

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database import get_db, Template, create_tables
from config import fill_placeholders
from ai_service_optimized import AIService

class TestTemplateSystem(unittest.TestCase):
    
    def setUp(self):
        """测试前准备"""
        os.environ['USE_SQLITE'] = 'true'
        create_tables()
        
    def test_fill_placeholders_single_braces(self):
        """测试单大括号占位符替换"""
        template = "你好{用户名}，您的兴趣是{兴趣}"
        params = {"用户名": "张三", "兴趣": "数码产品"}
        result = fill_placeholders(template, params)
        expected = "你好张三，您的兴趣是数码产品"
        self.assertEqual(result, expected)
        
    def test_fill_placeholders_double_braces(self):
        """测试双大括号占位符替换"""
        template = "库存信息：{{product_inventory}}，用户：{{用户名}}"
        params = {"product_inventory": "iPhone 15: 10台", "用户名": "李四"}
        result = fill_placeholders(template, params)
        expected = "库存信息：iPhone 15: 10台，用户：李四"
        self.assertEqual(result, expected)
        
    def test_fill_placeholders_mixed_format(self):
        """测试混合格式占位符替换"""
        template = "用户{用户名}的兴趣是{{兴趣}}，地址：{收货地址}"
        params = {
            "用户名": "王五",
            "兴趣": "摄影",
            "收货地址": "北京市朝阳区"
        }
        result = fill_placeholders(template, params)
        expected = "用户王五的兴趣是摄影，地址：北京市朝阳区"
        self.assertEqual(result, expected)
        
    def test_fill_placeholders_missing_params(self):
        """测试缺失参数的占位符处理"""
        template = "用户{用户名}，兴趣{兴趣}，未知{未知变量}"
        params = {"用户名": "赵六", "兴趣": "游戏"}
        result = fill_placeholders(template, params)
        expected = "用户赵六，兴趣游戏，未知{未知变量}"
        self.assertEqual(result, expected)
        
    def test_database_template_loading(self):
        """测试数据库模板加载"""
        db = next(get_db())
        try:
            existing_template = db.query(Template).filter(Template.name == "test_template").first()
            if existing_template:
                db.delete(existing_template)
                db.commit()
            
            ai_template = Template(
                name="test_template",
                content="测试模板：{用户名}的兴趣是{兴趣}",
                template_type="chat"
            )
            db.add(ai_template)
            db.commit()
            
            ai_service = AIService("test_api_key")
            template_content = ai_service._get_template_with_cache(db, "test_template", "test_user")
            
            self.assertIn("测试模板", template_content)
            
            raw_template = db.query(Template).filter(Template.name == "test_template").first()
            self.assertIsNotNone(raw_template)
            self.assertIn("{用户名}", raw_template.content)
            self.assertIn("{兴趣}", raw_template.content)
            
        finally:
            db.close()
            
    def test_ai_response_format_template_loading(self):
        """测试AI响应格式模板加载"""
        db = next(get_db())
        try:
            ai_service = AIService("test_api_key")
            template_content = ai_service._get_ai_response_format_template(db)
            
            self.assertIsInstance(template_content, str)
            self.assertTrue(len(template_content) > 0)
            
        finally:
            db.close()
            
    def test_template_caching(self):
        """测试模板缓存机制"""
        db = next(get_db())
        try:
            ai_service = AIService("test_api_key")
            
            template1 = ai_service._get_template_with_cache(db, "ai_response_format_template", "test_user")
            template2 = ai_service._get_template_with_cache(db, "ai_response_format_template", "test_user")
            
            self.assertEqual(template1, template2)
            
        finally:
            db.close()

class TestTemplateIntegration(unittest.TestCase):
    """集成测试：验证模板系统端到端功能"""
    
    def test_template_modification_workflow(self):
        """测试模板修改工作流程"""
        db = next(get_db())
        try:
            original_content = "原始模板内容：{ai_response_format}"
            modified_content = "修改后模板内容：{ai_response_format}"
            
            template = db.query(Template).filter(
                Template.template_type == "ai_response_format"
            ).first()
            
            if template:
                original_db_content = template.content
                template.content = modified_content
                db.commit()
                
                ai_service = AIService("test_api_key")
                retrieved_content = ai_service._get_ai_response_format_template(db)
                
                self.assertEqual(retrieved_content, modified_content)
                
                template.content = original_db_content
                db.commit()
                
        finally:
            db.close()
            
    def test_placeholder_replacement_integration(self):
        """测试占位符替换集成功能"""
        template = "用户{用户名}询问{商品类型}，当前库存：{product_inventory}"
        params = {
            "用户名": "测试用户",
            "商品类型": "手机",
            "product_inventory": "iPhone 15: 5台, 小米14: 8台"
        }
        
        result = fill_placeholders(template, params)
        expected = "用户测试用户询问手机，当前库存：iPhone 15: 5台, 小米14: 8台"
        
        self.assertEqual(result, expected)

def run_template_system_tests():
    """运行模板系统测试"""
    print("🧪 开始运行模板系统测试...")
    
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    suite.addTests(loader.loadTestsFromTestCase(TestTemplateSystem))
    suite.addTests(loader.loadTestsFromTestCase(TestTemplateIntegration))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    if result.wasSuccessful():
        print("✅ 所有测试通过！模板系统工作正常。")
        return True
    else:
        print("❌ 测试失败，请检查模板系统实现。")
        return False

if __name__ == "__main__":
    success = run_template_system_tests()
    sys.exit(0 if success else 1)
