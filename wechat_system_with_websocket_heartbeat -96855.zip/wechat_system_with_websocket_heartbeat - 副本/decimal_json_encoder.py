import json
from decimal import Decimal

class DecimalJSONEncoder(json.JSONEncoder):
    """自定义JSON编码器，处理Decimal类型"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalJSONEncoder, self).default(obj)

def decimal_json_dumps(obj):
    """使用自定义编码器将对象转换为JSON字符串"""
    return json.dumps(obj, cls=DecimalJSONEncoder)
