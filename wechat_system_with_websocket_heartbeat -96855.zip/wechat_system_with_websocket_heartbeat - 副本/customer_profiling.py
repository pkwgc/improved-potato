import json
import logging
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from database import User, WechatContact, IntentTracking, CustomerProfile, get_db

logger = logging.getLogger(__name__)

class CustomerProfilingService:
    """客户画像服务"""
    
    def __init__(self):
        self.profile_keywords = {
            "兴趣爱好": ["喜欢", "爱好", "兴趣", "热爱", "痴迷"],
            "购买偏好": ["便宜", "实惠", "高端", "品质", "性价比"],
            "消费能力": ["预算", "价格", "多少钱", "贵不贵"],
            "使用场景": ["工作", "家用", "送人", "自用", "办公"]
        }
    
    def analyze_customer_profile(self, db: Session, contact_id: int, message_content: str):
        """分析客户画像"""
        try:
            contact = db.query(WechatContact).filter(WechatContact.id == contact_id).first()
            if not contact:
                return False
            
            profiles = []
            for profile_type, keywords in self.profile_keywords.items():
                for keyword in keywords:
                    if keyword in message_content:
                        profile_value = self._extract_profile_value(message_content, keyword)
                        if profile_value:
                            profiles.append({
                                "type": profile_type,
                                "value": profile_value,
                                "confidence": 0.7
                            })
            
            for profile in profiles:
                existing_profile = db.query(CustomerProfile).filter(
                    CustomerProfile.contact_id == contact_id,
                    CustomerProfile.profile_type == profile["type"],
                    CustomerProfile.profile_value == profile["value"]
                ).first()
                
                if not existing_profile:
                    new_profile = CustomerProfile(
                        contact_id=contact_id,
                        profile_type=profile["type"],
                        profile_value=profile["value"],
                        confidence=profile["confidence"],
                        source='AI'
                    )
                    db.add(new_profile)
            
            db.commit()
            return True
            
        except Exception as e:
            logger.error(f"分析客户画像失败: {str(e)}")
            return False
    
    def _extract_profile_value(self, text: str, keyword: str) -> str:
        """提取画像值"""
        sentences = text.split('。')
        for sentence in sentences:
            if keyword in sentence:
                return sentence.strip()
        return ""
    
    def update_activity_score(self, db: Session, user_id: str):
        """更新活跃度评分"""
        try:
            user = db.query(User).filter(User.user_id == user_id).first()
            if not user:
                return False
            
            week_ago = datetime.now() - timedelta(days=7)
            recent_intents = db.query(IntentTracking).filter(
                IntentTracking.user_id == user.id,
                IntentTracking.detected_at >= week_ago
            ).count()
            
            activity_score = min(recent_intents * 10, 100)
            
            user.activity_score = activity_score
            user.last_active_time = datetime.now()
            db.commit()
            
            return True
            
        except Exception as e:
            logger.error(f"更新活跃度评分失败: {str(e)}")
            return False
    
    def calculate_conversion_rate(self, db: Session, user_id: str):
        """计算转化概率"""
        try:
            user = db.query(User).filter(User.user_id == user_id).first()
            if not user:
                return False
            
            high_intent_count = db.query(IntentTracking).filter(
                IntentTracking.user_id == user.id,
                IntentTracking.intent_type == "高意向"
            ).count()
            
            conversion_count = db.query(IntentTracking).filter(
                IntentTracking.user_id == user.id,
                IntentTracking.intent_type == "已成交"
            ).count()
            
            if high_intent_count > 0:
                conversion_rate = conversion_count / high_intent_count
            else:
                conversion_rate = 0.0
            
            user.conversion_rate = conversion_rate
            db.commit()
            
            return True
            
        except Exception as e:
            logger.error(f"计算转化概率失败: {str(e)}")
            return False
    
    def get_customer_tags(self, db: Session, user_id: str) -> list:
        """获取客户标签"""
        try:
            user = db.query(User).filter(User.user_id == user_id).first()
            if not user or not user.tags:
                return []
            
            return json.loads(user.tags)
            
        except Exception as e:
            logger.error(f"获取客户标签失败: {str(e)}")
            return []
    
    def add_customer_tag(self, db: Session, user_id: str, tag: str, source: str = 'AI'):
        """添加客户标签"""
        try:
            user = db.query(User).filter(User.user_id == user_id).first()
            if not user:
                return False
            
            existing_tags = []
            if user.tags:
                existing_tags = json.loads(user.tags)
            
            tag_data = {
                "tag": tag,
                "source": source,
                "created_at": datetime.now().isoformat()
            }
            
            if tag_data not in existing_tags:
                existing_tags.append(tag_data)
                user.tags = json.dumps(existing_tags, ensure_ascii=False)
                user.tag_source = source
                db.commit()
            
            return True
            
        except Exception as e:
            logger.error(f"添加客户标签失败: {str(e)}")
            return False
