import json
from user_profile_extractor import extract_user_profile_info, analyze_message_intent

def test_extraction():
    test_message = "帮我来2斤龙井，地址：海南省海口市龙华区城西商务中心1101，李庭皇，15203699059"
    
    intent_result = analyze_message_intent(test_message)
    print(f"意图识别结果: {intent_result}")
    
    profile_info = extract_user_profile_info(test_message)
    print(f"提取的用户资料信息: {json.dumps(profile_info, ensure_ascii=False, indent=2)}")
    
    test_messages = [
        "我要订购5斤铁观音，收货地址是北京市朝阳区建国路88号，联系人王小明，电话13812345678",
        "请帮我邮寄普洱茶3饼，送到上海市浦东新区张江高科技园区，收件人：张三，13987654321",
        "我的地址是广州市天河区体育西路123号，我叫李四，电话是13500001111，麻烦送2盒大红袍"
    ]
    
    for i, msg in enumerate(test_messages):
        print(f"\n测试消息 {i+1}: {msg}")
        intent = analyze_message_intent(msg)
        info = extract_user_profile_info(msg)
        print(f"意图识别: {intent}")
        print(f"提取信息: {json.dumps(info, ensure_ascii=False, indent=2)}")

if __name__ == "__main__":
    test_extraction()
