import json
import re
from sqlalchemy.orm import Session
from database import Intent, Industry

def extract_entities(text, patterns):
    """从文本中提取实体"""
    entities = {}
    for entity_name, pattern in patterns.items():
        match = re.search(pattern, text)
        if match:
            entities[entity_name] = match.group(1)
    return entities

def recognize_intent(db: Session, text, industry_name=None):
    """识别意图并返回相关信息"""
    if industry_name:
        industry = db.query(Industry).filter(Industry.name == industry_name).first()
        if industry:
            intents = db.query(Intent).filter(Intent.industry_id == industry.id).all()
            for intent in intents:
                keywords = json.loads(intent.parameters).get("keywords", [])
                for keyword in keywords:
                    if keyword in text:
                        return {
                            "intent": intent.name,
                            "industry": industry_name,
                            "api": intent.api_endpoint,
                            "confidence": 0.9,
                            "trigger_api": True,
                            "slots": extract_entities(text, json.loads(intent.parameters).get("patterns", {}))
                        }
    
    industries = db.query(Industry).all()
    for industry in industries:
        intents = db.query(Intent).filter(Intent.industry_id == industry.id).all()
        for intent in intents:
            keywords = json.loads(intent.parameters).get("keywords", [])
            for keyword in keywords:
                if keyword in text:
                    return {
                        "intent": intent.name,
                        "industry": industry.name,
                        "api": intent.api_endpoint,
                        "confidence": 0.8,
                        "trigger_api": True,
                        "slots": extract_entities(text, json.loads(intent.parameters).get("patterns", {}))
                    }
    
    return {
        "intent": None,
        "industry": None,
        "api": None,
        "confidence": 0.0,
        "trigger_api": False,
        "slots": {}
    }
