import os
import logging
from datetime import datetime, timedelta
from database import get_db, User, WechatContact, Moment, MomentComment, create_tables

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_test_moments():
    """创建测试朋友圈数据"""
    try:
        os.environ['USE_SQLITE'] = 'False'
        
        create_tables()
        
        db = next(get_db())
        
        user = db.query(User).filter(User.user_id == "test_user").first()
        if not user:
            user = User(
                user_id="test_user",
                username="测试用户",
                password="test123",
                is_admin=False,
                token_balance=1000
            )
            db.add(user)
            db.commit()
            logger.info("创建测试用户")
        
        wechat_contact = db.query(WechatContact).filter(
            WechatContact.wechat_id == "wxid_test123",
            WechatContact.owner_id == user.id
        ).first()
        if not wechat_contact:
            wechat_contact = WechatContact(
                wechat_id="wxid_test123",
                nickname="测试微信号",
                owner_id=user.id,
                parent_id=None,
                is_group=False
            )
            db.add(wechat_contact)
            db.commit()
            logger.info("创建测试微信账号")
        
        existing_moments = db.query(Moment).filter(Moment.owner_id == user.id).count()
        if existing_moments == 0:
            test_moments = [
                {
                    "wechat_id": "wxid_test123",
                    "content": "今天天气真不错，出去走走！",
                    "media_urls": ["https://picsum.photos/400/300?random=1", "https://picsum.photos/400/300?random=2"],
                    "like_count": 15,
                    "comment_count": 3,
                    "created_time": datetime.now() - timedelta(hours=2)
                },
                {
                    "wechat_id": "wxid_test123", 
                    "content": "分享一下今天的美食",
                    "media_urls": ["https://picsum.photos/400/300?random=3"],
                    "like_count": 8,
                    "comment_count": 1,
                    "created_time": datetime.now() - timedelta(hours=5)
                },
                {
                    "wechat_id": "wxid_test123",
                    "content": "工作中的小确幸 💪",
                    "media_urls": [],
                    "like_count": 12,
                    "comment_count": 2,
                    "created_time": datetime.now() - timedelta(days=1)
                }
            ]
            
            for moment_data in test_moments:
                moment = Moment(
                    wechat_id=moment_data["wechat_id"],
                    content=moment_data["content"],
                    media_urls=moment_data["media_urls"],
                    like_count=moment_data["like_count"],
                    comment_count=moment_data["comment_count"],
                    owner_id=user.id,
                    created_time=moment_data["created_time"]
                )
                db.add(moment)
                db.commit()
                
                if moment_data["comment_count"] > 0:
                    for i in range(moment_data["comment_count"]):
                        comment = MomentComment(
                            moment_id=moment.id,
                            parent_id=None,
                            wechat_id=f"friend_{i+1}",
                            content=f"这是第{i+1}条评论",
                            created_time=moment_data["created_time"] + timedelta(minutes=i*10)
                        )
                        db.add(comment)
                
                logger.info(f"创建测试朋友圈: {moment.content[:20]}...")
            
            db.commit()
            logger.info("测试朋友圈数据创建完成")
        else:
            logger.info("测试朋友圈数据已存在")
        
        db.close()
        
    except Exception as e:
        logger.error(f"创建测试数据失败: {str(e)}")

if __name__ == "__main__":
    create_test_moments()
