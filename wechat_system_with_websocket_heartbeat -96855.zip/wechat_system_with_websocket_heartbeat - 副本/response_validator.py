import json
import logging
import re
from typing import Dict, Any, Optional, List, Tuple
from jsonschema import validate, ValidationError
from config import AI_RESPONSE_FORMAT, AI_RESPONSE_SCHEMA

logger = logging.getLogger(__name__)

class ResponseValidator:
    """验证和修正AI响应格式"""
    
    def __init__(self):
        self.schema = AI_RESPONSE_SCHEMA
        self.default_format = AI_RESPONSE_FORMAT
        self.required_entities = {
            "下单": ["product"],
            "查询库存": ["product"],
            "查询价格": ["product"],
            "查询订单": ["order_id"]
        }
    
    def validate_response(self, response: Dict[str, Any]) -> bool:
        """验证响应是否符合预定义格式"""
        try:
            validate(instance=response, schema=self.schema)
            return True
        except ValidationError as e:
            logger.error(f"响应格式验证失败: {str(e)}")
            return False
    
    def fix_response(self, response: Any) -> Dict[str, Any]:
        """修正不符合格式的响应"""
        if isinstance(response, str):
            try:
                response = json.loads(response)
            except json.JSONDecodeError as e:
                logger.warning(f"标准JSON解析失败: {str(e)}")
                try:
                    fixed_json = self._fix_missing_commas(response)
                    response = json.loads(fixed_json)
                    logger.info("成功修复并解析JSON")
                except json.JSONDecodeError:
                    try:
                        fixed_json = self._fix_quote_issues(response)
                        response = json.loads(fixed_json)
                        logger.info("成功修复引号问题并解析JSON")
                    except json.JSONDecodeError:
                        try:
                            extracted_json = self._extract_json_object(response)
                            if extracted_json:
                                response = json.loads(extracted_json)
                                logger.info("成功提取并解析JSON对象")
                            else:
                                return self._create_default_response(response)
                        except json.JSONDecodeError:
                            return self._create_default_response(response)
        
        if not isinstance(response, dict):
            return self._create_default_response(str(response))
        
        fixed_response = self.default_format.copy()
        
        for key in fixed_response:
            if key in response:
                fixed_response[key] = response[key]
        
        if not isinstance(fixed_response.get("intent_details"), dict):
            fixed_response["intent_details"] = self.default_format["intent_details"].copy()
        else:
            for key in self.default_format["intent_details"]:
                if key not in fixed_response["intent_details"]:
                    fixed_response["intent_details"][key] = self.default_format["intent_details"][key]
        
        if fixed_response["intent_type"] not in ["specific_intent", "no_intent", "casual_chat"]:
            fixed_response["intent_type"] = "no_intent"
        
        self._validate_and_adjust_confidence(fixed_response)
        
        return fixed_response
    
    def _validate_and_adjust_confidence(self, response: Dict[str, Any]) -> None:
        """验证并调整置信度分数"""
        intent_type = response.get("intent_type", "no_intent")
        intent_details = response.get("intent_details", {})
        intent_name = intent_details.get("name")
        confidence = intent_details.get("confidence", 0.0)
        entities = intent_details.get("entities", {})
        
        if self._detect_intent_conflicts(response):
            logger.info("检测到意图冲突，降低置信度")
            confidence = min(confidence, 0.6)
        
        if intent_type == "specific_intent" and intent_name in self.required_entities:
            entity_completeness = self._check_entity_completeness(intent_name, entities)
            if entity_completeness < 1.0:
                logger.info(f"实体不完整，调整置信度: {entity_completeness}")
                confidence = confidence * entity_completeness
        
        
        if intent_type == "no_intent" and confidence > 0.2:
            logger.info(f"无意图但置信度过高 ({confidence:.2f})，调整为0.1")
            confidence = 0.1
        
        elif intent_type == "casual_chat":
            if confidence < 0.2:
                logger.info(f"闲聊意图但置信度过低 ({confidence:.2f})，调整为0.3")
                confidence = 0.3
            elif confidence > 0.6:
                logger.info(f"闲聊意图但置信度过高 ({confidence:.2f})，调整为0.5")
                confidence = 0.5
        
        elif intent_type == "specific_intent":
            if confidence < 0.4:
                logger.info(f"特定意图但置信度过低 ({confidence:.2f})，调整为no_intent")
                response["intent_type"] = "no_intent"
                intent_details["name"] = None
                confidence = 0.1
        
        intent_details["confidence"] = confidence
    
    def _detect_intent_conflicts(self, response: Dict[str, Any]) -> bool:
        """检测意图冲突"""
        intent_type = response.get("intent_type", "no_intent")
        intent_details = response.get("intent_details", {})
        intent_name = intent_details.get("name")
        
        reply = response.get("reply", "")
        intent_keywords = {
            "下单": ["购买", "下单", "买", "订购"],
            "查询库存": ["库存", "有货", "还有吗"],
            "查询价格": ["多少钱", "价格", "价钱"],
            "查询订单": ["订单", "物流", "发货"]
        }
        
        detected_intents = []
        for intent, keywords in intent_keywords.items():
            if any(keyword in reply for keyword in keywords):
                detected_intents.append(intent)
        
        return len(detected_intents) > 1 and intent_name in detected_intents
    
    def _check_entity_completeness(self, intent_name: str, entities: Dict[str, Any]) -> float:
        """检查实体完整性，返回完整度分数（0-1）"""
        required = self.required_entities.get(intent_name, [])
        if not required:
            return 1.0
        
        found = sum(1 for entity in required if entity in entities)
        return found / len(required)
    
    def _create_default_response(self, content: str) -> Dict[str, Any]:
        """创建默认响应格式"""
        return {
            "reply": content,
            "intent_type": "no_intent",
            "intent_details": {
                "name": None,
                "confidence": 0.0,
                "entities": {}
            },
            "user_info_detected": {},
            "order_info": None
        }
    
    def extract_intent_type(self, response: Dict[str, Any]) -> str:
        """提取意图类型"""
        return response.get("intent_type", "no_intent")
    
    def extract_intent_details(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """提取意图详情"""
        return response.get("intent_details", {})
    
    def extract_user_info(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """提取用户信息"""
        return response.get("user_info_detected", {})
    
    def extract_order_info(self, response: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """提取订单信息"""
        return response.get("order_info")
    
    def validate_inventory_consistency(self, response_text: str, user_inventory: Optional[Dict[str, Any]]) -> Tuple[bool, List[str]]:
        """验证AI回复是否与用户库存一致
        
        Args:
            response_text: AI回复内容
            user_inventory: 用户库存数据
            
        Returns:
            (是否一致, 违规商品列表)
        """
        if not user_inventory or not user_inventory.get("items"):
            product_mentions = self._extract_product_mentions(response_text)
            if product_mentions:
                logger.warning(f"用户无库存但AI提及商品: {product_mentions}")
                return False, product_mentions
            return True, []
        
        inventory_items = user_inventory.get("items", [])
        inventory_products = set()
        
        for item in inventory_items:
            product_name = item.get("产品名称", "")
            if product_name:
                inventory_products.add(product_name.strip())
        
        mentioned_products = self._extract_product_mentions(response_text)
        
        invalid_products = []
        for product in mentioned_products:
            if not any(inv_product in product or product in inv_product for inv_product in inventory_products):
                invalid_products.append(product)
        
        if invalid_products:
            logger.warning(f"AI提及了不在库存中的商品: {invalid_products}")
            return False, invalid_products
        
        return True, []
    
    def _extract_product_mentions(self, text: str) -> List[str]:
        """从文本中提取商品名称"""
        import re
        
        product_patterns = [
            r'([一-龯]{2,6}茶)',
            r'([一-龯]{2,8}(?:产品|商品|货品))',
            r'([一-龯]{2,6}(?:机|器|设备))',
            r'([一-龯]{2,6}(?:服务|套餐))',
        ]
        
        mentioned_products = set()
        for pattern in product_patterns:
            matches = re.findall(pattern, text)
            mentioned_products.update(matches)
        
        generic_words = {"商品", "产品", "货品", "服务", "套餐", "设备"}
        mentioned_products = [p for p in mentioned_products if p not in generic_words and len(p) > 1]
        
        return list(mentioned_products)
        
    def _fix_missing_commas(self, json_str: str) -> str:
        """修复缺少逗号的JSON字符串"""
        pattern = r'("[^"]+"\s*:\s*[^{}\[\],\s]+)\s*("[^"]+"\s*:)'
        fixed = re.sub(pattern, r'\1,\2', json_str)
        
        pattern = r'(\[[^\[\]]*?[^,\[\]\s])\s*([^,\[\]\s][^\[\]]*?\])'
        fixed = re.sub(pattern, r'\1,\2', fixed)
        
        pattern = r'({[^{}]*?[^,{}\s])\s*([^,{}\s][^{}]*?})'
        fixed = re.sub(pattern, r'\1,\2', fixed)
        
        logger.debug(f"修复前: {json_str}")
        logger.debug(f"修复后: {fixed}")
        return fixed
    
    def _fix_quote_issues(self, json_str: str) -> str:
        """修复引号问题的JSON字符串"""
        fixed = json_str.replace("'", '"')
        
        pattern = r'([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:'
        fixed = re.sub(pattern, r'\1"\2":', fixed)
        
        pattern = r':\s*([a-zA-Z_][a-zA-Z0-9_\s]*[a-zA-Z0-9_])([,}])'
        fixed = re.sub(pattern, r':"\1"\2', fixed)
        
        logger.debug(f"引号修复前: {json_str}")
        logger.debug(f"引号修复后: {fixed}")
        return fixed
    
    def _extract_json_object(self, text: str) -> Optional[str]:
        """从文本中提取JSON对象"""
        json_pattern = r'({[\s\S]*?})'
        matches = re.findall(json_pattern, text)
        
        if not matches:
            return None
        
        for match in matches:
            try:
                json.loads(match)
                return match
            except json.JSONDecodeError:
                continue
        
        largest_match = max(matches, key=len) if matches else None
        if largest_match:
            try:
                fixed = self._fix_missing_commas(largest_match)
                fixed = self._fix_quote_issues(fixed)
                json.loads(fixed)  # 验证是否有效
                return fixed
            except json.JSONDecodeError:
                pass
        
        code_block_pattern = r'```(?:json)?\s*([\s\S]*?)```'
        code_matches = re.findall(code_block_pattern, text)
        
        for code in code_matches:
            try:
                json.loads(code.strip())
                return code.strip()
            except json.JSONDecodeError:
                try:
                    fixed = self._fix_missing_commas(code.strip())
                    fixed = self._fix_quote_issues(fixed)
                    json.loads(fixed)
                    return fixed
                except json.JSONDecodeError:
                    continue
        
        return None
