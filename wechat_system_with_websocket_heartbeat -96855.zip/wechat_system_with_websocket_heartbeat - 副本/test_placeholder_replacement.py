import unittest
from config import fill_placeholders

class TestPlaceholderReplacement(unittest.TestCase):
    """测试统一占位符替换功能"""
    
    def test_single_brace_placeholders(self):
        """测试单大括号占位符"""
        template = "您好{name}，您的兴趣是{兴趣}，库存：{product_inventory}"
        params = {
            "name": "张三",
            "兴趣": "茶叶",
            "product_inventory": "龙井茶 10盒"
        }
        result = fill_placeholders(template, params)
        expected = "您好张三，您的兴趣是茶叶，库存：龙井茶 10盒"
        self.assertEqual(result, expected)
    
    def test_double_brace_placeholders(self):
        """测试双大括号占位符"""
        template = "您好{{name}}，您的兴趣是{{兴趣}}，库存：{{product_inventory}}"
        params = {
            "name": "李四",
            "兴趣": "咖啡",
            "product_inventory": "蓝山咖啡 5包"
        }
        result = fill_placeholders(template, params)
        expected = "您好李四，您的兴趣是咖啡，库存：蓝山咖啡 5包"
        self.assertEqual(result, expected)
    
    def test_mixed_placeholders(self):
        """测试混合占位符格式"""
        template = "用户{name}的行业是{{行业}}，收货地址：{收货地址}"
        params = {
            "name": "王五",
            "行业": "电商",
            "收货地址": "北京市朝阳区"
        }
        result = fill_placeholders(template, params)
        expected = "用户王五的行业是电商，收货地址：北京市朝阳区"
        self.assertEqual(result, expected)
    
    def test_missing_placeholders(self):
        """测试缺失占位符的处理"""
        template = "用户{name}的爱好是{missing_hobby}"
        params = {"name": "赵六"}
        result = fill_placeholders(template, params)
        expected = "用户赵六的爱好是{missing_hobby}"
        self.assertEqual(result, expected)

if __name__ == "__main__":
    unittest.main()
